rm(list=ls())
#######################################################################################################
## Supplement B for "Modeling and Forecasting Electricity Spot Prices"                               ## 
## File:   1_TwoStepEstim.R                                                                          ##
## 1.STEP: Estimation of price-demand functions                                                      ##
## 2.STEP: Determination of common basis functions (eigenfunctions of the covariance function gamma) ##
##                                                                                                   ##
## Author: Dominik Liebl                                                                             ##
##         dliebl@uni-bonn.de                                                                        ##
## Date:   Mar.2013                                                                                  ##
#######################################################################################################              

## Load external Packages #####
require(pspline)             ##
require(locfit)              ##
###############################

## Import Data ##############################
data.selector <- "all"                     ##
source("AUX_FUN_and_DATA/Data.Import.R")   ##
## ##########################################

## Outliers Handling ###############
price.Otl      <- 200             ##
## #################################

## Number of Factors ##
K <- 2               ##
#######################

## DATA =======================================================================================
Y.mat                     <- ord.RL.Prices # electricity spot prices
U.mat                     <- ord.RL        # electrictiy demand (gross electr. demand minus electr. wind infeed)
Da.mat                    <- ord.RL.Dates  # matrix of dates
N # N = 24 hours/day
T # T = 717 (workdays Mo.-Fr.) - 79 (Holidays and Br��ckentage)

## Outlier Handling: ==========================================================================
Y.mat.orig  <- Y.mat
U.mat.orig  <- U.mat
  
Y.vec       <- as.vector(Y.mat)
U.vec       <- as.vector(U.mat)

U.vec[Y.vec > price.Otl] <- NA
Y.vec[Y.vec > price.Otl] <- NA

Y.mat       <- matrix(Y.vec, N,T)
U.mat       <- matrix(U.vec, N,T)

Y.vec.orig  <- as.vector(Y.mat.orig)

## Percentage of Outliers: (1-("Number of Data without Outliers")/("Number of Data with Outliers"))*100
round((1-length(Y.vec[!is.na(Y.vec)])/length(Y.vec.orig))*100,digits=2)

## re-order into hourly data: ================================================================
re.ord.Y.mat  <- matrix(NA,N,T)
re.ord.U.mat  <- matrix(NA,N,T)
re.ord.RL.mat <- matrix(NA,N,T)
re.ord.Da.mat <- matrix(NA,N,T)

for(t in 1:T){
  re.ord.Y.mat[ ,t] <- Y.mat[order(ord.mat[,t]),t]
  re.ord.U.mat[,t]  <- U.mat[order(ord.mat[,t]),t]
  re.ord.RL.mat[,t] <- ord.RL[order(ord.mat[,t]),t]
  re.ord.Da.mat[,t] <- Da.mat[order(ord.mat[,t]),t]
}

#####################################################################################################################
## 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  #### 1.STEP  ##
#####################################################################################################################

###########################################
## Pre-Smoothing of the functions        ##
## under-smoothed:    X.smUSmth          ##
## GCV-smoothed:      X.smGCVSmth        ##
## GCV: Generalized Cross Validation     ##
###########################################

X.smGCVSmth        <- vector("list",T)

## Determination of GCV-smoothing parameter:
tmp.gcv <- NULL
for(t in 1:T){
  tmp.gcv <- c(tmp.gcv,sm.spline(x=U.mat[,t][!is.na(U.mat[,t])], y= Y.mat[,t][!is.na( Y.mat[,t])])$spar)
}
spar.GCV  <- median(tmp.gcv)

for(t in 1:T){
  ## ordinary-smoothing 
  X.smGCVSmth[[t]] <- sm.spline(x=U.mat[,t][!is.na(U.mat[,t])],y= Y.mat[,t][!is.na( Y.mat[,t])], spar=spar.GCV)
}

## Undersmoothing: CV-Smoothing-Parameters for K=1,2,3
## Determined externally via crossvalidation (see Eq. (5))
min.spar.seq.K1    <- 5e+09
min.spar.seq.K2    <- 7e+09
min.spar.seq.K3    <- 1e+10

CV.USmth.spar <- switch(as.character(K),
                        "1" = min.spar.seq.K1,
                        "2" = min.spar.seq.K2,
                        "3" = min.spar.seq.K3)

X.smUSmth          <- vector("list",T)
for(t in 1:T){
  ## undersmoothing using the cross validation undersmoothing parameter
  X.smUSmth[[t]]   <- sm.spline(x=U.mat[,t][!is.na(U.mat[,t])],y= Y.mat[,t][!is.na( Y.mat[,t])],
                                spar=CV.USmth.spar)
}

#########################
## Plots for Figure 1: ##
#########################

## Plot: Electrictiy-demand
par(mfrow=c(3,1))
scl     <- 1
scl.axs <- 1.2
scl.lab <- 1.3
plot(as.vector(re.ord.RL.mat[,c(502:506)]),xlab="Hours",
        ylab="GW", type="l",axes=FALSE, cex.lab=scl.lab, cex.axis=scl.axs, frame=TRUE,
     main="Time Series of Electricity Demand (5 Work days: March 3-7, 2008)")
lines(y=range(re.ord.RL.mat[,c(502:506)]), x=rep(1*24,2),lty=3)
lines(y=range(re.ord.RL.mat[,c(502:506)]), x=rep(2*24,2),lty=3)
lines(y=range(re.ord.RL.mat[,c(502:506)]), x=rep(3*24,2),lty=3)
lines(y=range(re.ord.RL.mat[,c(502:506)]), x=rep(4*24,2),lty=3)
axis(1, cex.axis=scl.axs);
axis(2, at=seq(min(re.ord.RL.mat[,c(502:506)]),max(re.ord.RL.mat[,c(502:506)]),length=10),
     labels=round(seq(min(re.ord.RL.mat[,c(502:506)]),max(re.ord.RL.mat[,c(502:506)]),length=10)/1000,digits=0),
     cex.axis=scl.axs)
## Dates:
re.ord.Da.mat[1,502]; re.ord.Da.mat[1,506]

## Plot: Electricity spot prices in original hourly order
plot(as.vector(re.ord.Y.mat[,c(502:506)]),xlab="Hours", ylim=range(re.ord.Y.mat[,c(502:506)], na.rm=T),
        ylab="EUR/MWh", type="l",axes=FALSE, cex.lab=scl.lab, cex.axis=scl.axs, frame=TRUE,
     main="Time Series of Electricity Spot Prices (5 Work days: March 3-7, 2008)")
lines(y=range(re.ord.Y.mat[,c(502:506)]), x=rep(1*24,2),lty=3)
lines(y=range(re.ord.Y.mat[,c(502:506)]), x=rep(2*24,2),lty=3)
lines(y=range(re.ord.Y.mat[,c(502:506)]), x=rep(3*24,2),lty=3)
lines(y=range(re.ord.Y.mat[,c(502:506)]), x=rep(4*24,2),lty=3)
axis(1, cex.axis=scl.axs);
axis(2, at=seq(20,90,by=10),labels=seq(20,90,by=10), cex.axis=scl.axs)

## Plot: Electricity spot prices in electricity-demand order
source("AUX_FUN_and_DATA/plot_5_price_demand_fcts.R")
par(mfrow=c(1,1))
dev.off()


########################
## Plot for Figure 2: ##
########################

u.fix.1             <- 58000
u.fix.2             <- 70000
prices.controlled.1 <- NULL
prices.controlled.2 <- NULL
i <- 1
DUMMYFEIER.withoutSASU <- DUMMYFEIER[!c(as.logical(DUMMYSU)|as.logical(DUMMYSA))]
for(t in 1:length(DUMMYFEIER.withoutSASU)){
  if(DUMMYFEIER.withoutSASU[t]==0){
    prices.controlled.1 <- c(prices.controlled.1, predict(X.smGCVSmth[[i]], u.fix.1))
    prices.controlled.2 <- c(prices.controlled.2, predict(X.smGCVSmth[[i]], u.fix.2))
    i <- i+1        
  }else{
    prices.controlled.1 <- c(prices.controlled.1, NA)
    prices.controlled.2 <- c(prices.controlled.2, NA)
  }
}

## plot:
scl     <- 1; scl.axs <- 1.4; scl.lab <- 1.4
plot(prices.controlled.2, ylab="EUR/MWh", xlab="Work days (January 1, 2006 - September 30, 2008)", type="l",
     cex.lab=scl.lab, cex.axis=scl.axs, axes=FALSE, frame=TRUE,  main="")
axis(1, cex.axis=scl.axs);axis(2, cex.axis=scl.axs)
par(mfrow=c(1,1))
dev.off()

###############################################
## Discretization of price-demand functions  ##
## at the observed values of electr. demand. ## 
###############################################

N                        <- 24
U.mat.orig.without.Otl   <- U.mat
Y.mat.orig.without.Otl   <- Y.mat
X.tilde.mat              <- matrix(NA,N,T)
X.hat.mat                <- matrix(NA,N,T)
tmp                      <- matrix(NA,N,T)
for(t in 1:T){  
  tmp[,t]                  <- seq(min(U.mat[,t],na.rm=T), max(U.mat[,t],na.rm=T), length.out=N)
  X.tilde.mat[,t]          <- predict(X.smUSmth[[t]],  tmp[,t] )
  X.hat.mat[,t]            <- predict(X.smGCVSmth[[t]], tmp[,t] )  
}
U.mat                    <- tmp
X.tilde.mat.vec          <- as.vector(X.tilde.mat)
X.hat.mat.vec            <- as.vector(X.hat.mat)
U.mat.vec                <- as.vector(U.mat)

###############################################################
## Standardization of the discretized price-demand functions ##
###############################################################

## Scaling-parameter: ||\hat{X}_t||
c_t       <- numeric(T)
for(t in 1:T){
  X.hat_t     <- X.hat.mat[,t][!is.na(X.hat.mat[,t])]
  X.hat_t.sq  <- (X.hat_t^2)
  c_t[t]      <- sqrt(sum(X.hat_t.sq))
}

X.hat.scaled.mat    <- matrix(nrow=N,ncol=T)
X.tilde.scaled.mat  <- matrix(nrow=N,ncol=T)

## standardization:
for(t in 1:T){
  X.hat.scaled.mat[,t][!is.na(X.tilde.mat[,t])]   <- (c(X.tilde.mat[,t][!is.na(X.tilde.mat[,t])])/c_t[t])
  X.tilde.scaled.mat[,t][!is.na(X.hat.mat[,t])]   <- (c(X.hat.mat[,t][!is.na(X.hat.mat[,t])])/c_t[t])
}
X.tilde.normal.mat       <- X.tilde.mat
X.tilde.normal.mat.vec   <- as.vector(X.tilde.normal.mat)
X.hat.normal.mat         <- X.hat.mat
X.hat.normal.mat.vec     <- as.vector(X.hat.normal.mat)

## overwriting by the scaled data:
X.tilde.mat              <- X.hat.scaled.mat
X.hat.mat                <- X.tilde.scaled.mat
X.tilde.mat.vec          <- as.vector(X.tilde.mat)
X.hat.mat.vec            <- as.vector(X.hat.mat)

#####################################################################################################################
## 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  #### 2.STEP  ##
#####################################################################################################################

##########################################################################################
## Preparation of compution of the cov-function gamma (see Yao M��ller & Wang JASA 2005) ##
##########################################################################################

source("AUX_FUN_and_DATA/raw_cov_data.R")

##############################################################################
## Computation of emp. covariance-function gamma by local surface smoothing ##
##############################################################################

G.hat          <- locfit(G.vec~lp(U_i.rmd, U_j.rmd)) # G.vec holds the values: \hat{X}_t^\ast(u_{ti})*\hat{X}_t^\ast(u_{tj})

## Plot Covariance-Function gamma-hat
## Evaluation grid for the plot of the covariance function:
n.ev.points    <- 50
grid.list      <- vector("list",2)
grid.list[[1]] <- seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points)
grid.list[[2]] <- seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points)
## Evaluation
G.hat.m        <- matrix(predict(G.hat, newdata=grid.list), nrow=n.ev.points, ncol=n.ev.points)

###########################
## Figure 3 (Left panel) ##
###########################
hgt <- 0.25 * (G.hat.m[-n.ev.points,-n.ev.points] + G.hat.m[-1,-n.ev.points] + G.hat.m[-n.ev.points,-1] + G.hat.m[-1,-1])
hgt <- (hgt - min(hgt))/ (max(hgt) - min(hgt))

scl     <- 1
scl.axs <- 1.4
scl.lab <- 1.4
par(oma=c(0,0,0,0),mar=c(0,1.8,0,1.1),cex=scl, cex.lab=scl.lab, cex.axis=scl.axs)
persp.m <- persp(x=grid.list[[1]], y=grid.list[[2]], z=G.hat.m,
                 main="", xlab="MW", ylab="MW",zlab="", col=gray(1 - hgt),
                 theta=340, phi=10, r=50, d=0.7, expand=1, ltheta=90,
                 lphi=180, shade=0.001, ticktype="detailed", nticks=3)
par(mar=c(5.1, 4.1, 4.1, 2.1))
dev.off()

##===============================================================================================

##########################
## fPCA                 ##
##########################

len.Interval <- max(U.mat, na.rm=TRUE)-min(U.mat, na.rm=TRUE)
n            <- dim(G.hat.m)[1]
h            <- (len.Interval)/(n-1)
w            <- rep(h,n)
W            <- diag(w)
e.analy      <- eigen(sqrt(W)%*%G.hat.m%*%sqrt(W), symmetric=TRUE)
e.v          <- e.analy[[1]]
e.vec        <- e.analy[[2]]
sum(e.v)

length(e.v[e.v>0])

## Interpolation of Eigenvectors "e.vec.ast":
e.vec.ast    <- solve(sqrt(W))%*%e.vec
## Check Size:
t(e.vec.ast[,1]) %*% W %*% e.vec.ast[,1]

## Shares on total Variance
var.shares   <- ((e.v[e.v>0])/sum(e.v[e.v>0]))
round(var.shares[1:4],digits=4)*100
cumsum(round(var.shares[1:4],digits=4)*100)

## Interpolation of eigenvectors =======================================================================
e.fun.hat              <- smooth.Pspline(x = seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points),
                                         y = e.vec.ast[,1:length(e.v[e.v>0])])
## plot eigenfunctions 
source("AUX_FUN_and_DATA/plot_eigenfunctions.R")

######################################################################################
## Evaluate eigen-functions at observed sample-points of electricity-demand (u_{th})##
######################################################################################

phi.i.hat            <- vector("list", T)
for(t in 1:T){
  tmp.U             <- U.mat[,t][!is.na(U.mat[,t])]
  phi.i.hat[[t]]     <- predict(e.fun.hat, tmp.U)
}

################################################
## Determination of the number of Factors "K" ##
################################################

## AIC of Yao et al. 2005:
source("AUX_FUN_and_DATA/AIC.criterion.R")
(AIC.K1 <- -L1+1) 
(AIC.K2 <- -L2+2) 
(AIC.K3 <- -L3+3)

## As differences from AIC.K2:
round(AIC.K1-AIC.K2, digits=1)
round(AIC.K2-AIC.K2, digits=1)
round(AIC.K3-AIC.K2, digits=1)

## Check Variance-Shares of first K eigenvalues
cumsum(round(var.shares[1:3],digits=4)*100)

########################################################################################################
## Determine projection parameters \beta_{tk} by Least-Squares (here: \beta_{th} are called "scores") ## 
########################################################################################################

scores     <- matrix(NA,2,T)
for(t in 1:T){
  tmp.lm   <- summary(lm(as.vector(X.hat.normal.mat[,t][!is.na(X.hat.normal.mat[,t])])~0 +
                         as.vector(phi.i.hat[[t]][,1])+
                         as.vector(phi.i.hat[[t]][,2])
                         ))
  scores[,t] <- tmp.lm$coefficients[,1]
}
## Plot time serie of scores: \beta_{t1} and \beta_{t2}
## This are the non-rotated versions! Figure 3 (right panel) is produced in the R-file VARIMAX.R.
par(mfrow=c(2,1))
plot.ts(scores[1,])
plot.ts(scores[2,])
par(mfrow=c(1,1))
dev.off()

###############
## Residuals ##
###############

Y.vec.RES       <- as.vector(Y.mat.orig)
U.vec.RES       <- as.vector(U.mat.orig)

U.vec.RES[Y.vec.RES  > price.Otl] <- NA
Y.vec.RES[Y.vec.RES  > price.Otl] <- NA

Y.mat.RES       <- matrix(Y.vec.RES,  24,T)
U.mat.RES       <- matrix(U.vec.RES, 24,T)

RES.mat <- matrix(NA, 24, T)

for(t in 1:T){
  RES.mat[,t][!is.na(U.mat.RES[,t])] <-c(Y.mat.RES[,t][complete.cases(U.mat.RES[,t])])-
    c((predict(e.fun.hat, U.mat.RES[,t][complete.cases(U.mat.RES[,t])])[,1])*scores[1,t]+
      (predict(e.fun.hat, U.mat.RES[,t][complete.cases(U.mat.RES[,t])])[,2])*scores[2,t])
}

RES.vec   <- as.vector(RES.mat)
RES.vec   <- RES.vec[!is.na(RES.vec)]
Y.vec.RES <- Y.vec.RES[!is.na(Y.vec.RES)]

######################
## R-square (R^2)   ##
######################

SS.total  <- sum(c(Y.vec.RES-mean(Y.vec.RES))^2)
R.sqr     <- 1-sum(c(RES.vec)^2)/SS.total

round(R.sqr, digits=2)

## ===============================================================================================
## Save working-space:
save.image(file="TwoStepEstim.RData")
## ===============================================================================================

###################################################################################################
## Next: Execute the R-file "VARIMAX.R" in order to rotated the estimated common basis functions ##
###################################################################################################
