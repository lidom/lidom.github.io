plot(y=predict(X.smUSmth[[502]], seq(min(U.mat[,502],na.rm=T), max(U.mat[,502],na.rm=T), 40)),
     x=seq(min(U.mat[,502],na.rm=T), max(U.mat[,502],na.rm=T), 40),
     type="l", ylab="EUR/MWh", xlab="GW", cex.lab=scl.lab, cex.axis=scl.axs,
     xlim=range(c(
       min(U.mat[,502],na.rm=T),
       max(U.mat[,506],na.rm=T)-min(U.mat[,506],na.rm=T)+
       max(U.mat[,505],na.rm=T)-min(U.mat[,505],na.rm=T)+
       max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
       max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*4*1000)),
##      ylim=range(c(
##        predict(X.smUSmth[[502]], seq(min(U.mat[,502],na.rm=T), max(U.mat[,502],na.rm=T), 40)),
##        predict(X.smUSmth[[503]], seq(min(U.mat[,503],na.rm=T), max(U.mat[,503],na.rm=T), 40)),
##        predict(X.smUSmth[[504]], seq(min(U.mat[,504],na.rm=T), max(U.mat[,504],na.rm=T), 40)),
##        predict(X.smUSmth[[505]], seq(min(U.mat[,505],na.rm=T), max(U.mat[,505],na.rm=T), 40)),
##        predict(X.smUSmth[[506]], seq(min(U.mat[,506],na.rm=T), max(U.mat[,506],na.rm=T), 40))
##        ), na.rm=T),
       ylim=range(re.ord.Y.mat[,c(502:506)], na.rm=T),
       axes=FALSE, frame=TRUE,
     main="Time Series of Price-Demand Functions (5 Work days: March 3-7, 2008)"
     )
axis(2, at=seq(20,90,by=10),labels=seq(20,90,by=10), cex.axis=scl.axs)
points(y=Y.mat[,502],x=U.mat[,502])
## Mo
axis(1,at=c(
         seq(min(U.mat[,502],na.rm=T), max(U.mat[,502],na.rm=T), length=5)          
         ), labels=round(c(
              seq(min(U.mat[,502],na.rm=T), max(U.mat[,502],na.rm=T), length=5)
              )/1000,digits=0), cex.axis=scl.axs, line=.3)
## Tu
axis(1,at=c(
          seq(min(U.mat[,503],na.rm=T), max(U.mat[,503],na.rm=T), length=5)-min(U.mat[,503],na.rm=T)+
              max(U.mat[,502],na.rm=T)+5*1000   
         ), labels=round(c(
              seq(min(U.mat[,503],na.rm=T), max(U.mat[,503],na.rm=T), length=5)
              )/1000,digits=0), cex.axis=scl.axs, line=.3)
## We
axis(1,at=c(
          seq(min(U.mat[,504],na.rm=T), max(U.mat[,504],na.rm=T), length=5)-min(U.mat[,504],na.rm=T)+
              max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*2*1000
         ), labels=round(c(
              seq(min(U.mat[,504],na.rm=T), max(U.mat[,504],na.rm=T), length=5)
              )/1000,digits=0), cex.axis=scl.axs, line=.3)
## Th
axis(1,at=c(
          seq(min(U.mat[,505],na.rm=T), max(U.mat[,505],na.rm=T), length=5)-min(U.mat[,505],na.rm=T)+
              max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
              max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*3*1000
         ), labels=round(c(
              seq(min(U.mat[,505],na.rm=T), max(U.mat[,505],na.rm=T), length=5) 
              )/1000,digits=0), cex.axis=scl.axs, line=.3)
## Fr
axis(1,at=c(
         seq(min(U.mat[,506],na.rm=T), max(U.mat[,506],na.rm=T), length=5)-min(U.mat[,506],na.rm=T)+
                  max(U.mat[,505],na.rm=T)-min(U.mat[,505],na.rm=T)+
                  max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
                  max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*4*1000     
         ), labels=round(c(
              seq(min(U.mat[,506],na.rm=T), max(U.mat[,506],na.rm=T), length=5)
              )/1000,digits=0), cex.axis=scl.axs, line=.3)
## Separation-Lines
lines(y=c(20.13141, 87.48051), x=rep(max(U.mat[,502],na.rm=T)+
                                 2.5*1000,2),lty=3)
lines(y=c(20.13141, 87.48051), x=rep(max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+
                                 5*2*1000  -2.5*1000,2),lty=3)
lines(y=c(20.13141, 87.48051), x=rep(max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
              max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+
                                 5*3*1000-2.5*1000,2),lty=3)
lines(y=c(20.13141, 87.48051), x=rep(max(U.mat[,505],na.rm=T)-min(U.mat[,505],na.rm=T)+
                  max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
                  max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+
                                 5*4*1000-2.5*1000,2),lty=3)

## Price-Demand Curves
## Tu
lines(y=predict(X.smUSmth[[503]], seq(min(U.mat[,503],na.rm=T), max(U.mat[,503],na.rm=T), 40)),
      x=c(seq(min(U.mat[,503],na.rm=T), max(U.mat[,503],na.rm=T), 40)-min(U.mat[,503],na.rm=T)+
          max(U.mat[,502],na.rm=T)+5*1000
        )
      )
points(y=Y.mat[,503],
       x=c(U.mat[,503]-min(U.mat[,503],na.rm=T)+
          max(U.mat[,502],na.rm=T)+5*1000))
## We
lines(y=predict(X.smUSmth[[504]], seq(min(U.mat[,504],na.rm=T), max(U.mat[,504],na.rm=T), 40)),
      x=c(seq(min(U.mat[,504],na.rm=T), max(U.mat[,504],na.rm=T), 40)-min(U.mat[,504],na.rm=T)+
          max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*2*1000
        )
      )
points(y=Y.mat[,504],
       x=c(U.mat[,504]-min(U.mat[,504],na.rm=T)+
          max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*2*1000))
## Th
lines(y=predict(X.smUSmth[[505]], seq(min(U.mat[,505],na.rm=T), max(U.mat[,505],na.rm=T), 40)),
      x=c(seq(min(U.mat[,505],na.rm=T), max(U.mat[,505],na.rm=T), 40)-min(U.mat[,505],na.rm=T)+
        max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
        max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*3*1000
        )
      )
points(y=Y.mat[,505],
       x=c(U.mat[,505]-min(U.mat[,505],na.rm=T)+
        max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
        max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*3*1000))
## Fr
lines(y=predict(X.smUSmth[[506]], seq(min(U.mat[,506],na.rm=T), max(U.mat[,506],na.rm=T), 40)),
      x=c(seq(min(U.mat[,506],na.rm=T), max(U.mat[,506],na.rm=T), 40)-min(U.mat[,506],na.rm=T)+
        max(U.mat[,505],na.rm=T)-min(U.mat[,505],na.rm=T)+
        max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
        max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*4*1000
        )
      )
points(y=Y.mat[,506],
       x=c(U.mat[,506]-min(U.mat[,506],na.rm=T)+
        max(U.mat[,505],na.rm=T)-min(U.mat[,505],na.rm=T)+
        max(U.mat[,504],na.rm=T)-min(U.mat[,504],na.rm=T)+
        max(U.mat[,503],na.rm=T)-min(U.mat[,503],na.rm=T)+max(U.mat[,502],na.rm=T)+5*4*1000))
