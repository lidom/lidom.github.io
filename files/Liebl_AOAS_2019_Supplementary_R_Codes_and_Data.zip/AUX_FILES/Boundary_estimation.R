## #############################################################################
## #############################################################################
Myunimod.selector <- function(vec, extremum=c("Max","Min")){
  if(extremum=="Max"){
    max.loc              <- order(vec, decreasing=TRUE)[1]
    c.mon.incr.vec       <- vec[1:(max.loc)]
    c.mon.decr.vec       <- vec[max.loc:length(vec)]
    
    c.mon.incr.posis     <- which(c.mon.incr.vec==c.mon.incr.vec[order(c.mon.incr.vec, decreasing=TRUE)][1])
    if(length(c.mon.incr.vec)>1){
    for(i in 2:length(c.mon.incr.vec)){
      new.pos <- which(c.mon.incr.vec==c.mon.incr.vec[order(c.mon.incr.vec, decreasing=TRUE)][i])
      new.pos <- min(new.pos)
      if(new.pos<min(c.mon.incr.posis)){
        c.mon.incr.posis  <- c(c.mon.incr.posis, new.pos)
      }
    }}
    c.mon.decr.posis  <- which(c.mon.decr.vec==c.mon.decr.vec[order(c.mon.decr.vec, decreasing=TRUE)][1])
    if(length(c.mon.decr.vec)>1){
    for(i in 2:length(c.mon.decr.vec)){
      new.pos <- which(c.mon.decr.vec==c.mon.decr.vec[order(c.mon.decr.vec, decreasing=TRUE)][i])
      new.pos <- max(new.pos)
      if(new.pos>max(c.mon.decr.posis)){
        c.mon.decr.posis  <- c(c.mon.decr.posis, new.pos)
      }
    }}
    locs <- c(rev(c.mon.incr.posis), c(max.loc-1+c.mon.decr.posis)[-1])
  }
  if(extremum=="Min"){
    min.loc              <- order(vec)[1]
    c.mon.decr.vec       <- vec[1:(min.loc)]
    c.mon.incr.vec       <- vec[min.loc:length(vec)]
    
    c.mon.incr.posis     <- which(c.mon.incr.vec==c.mon.incr.vec[order(c.mon.incr.vec)][1])
    if(length(c.mon.incr.vec)>1){
    for(i in 2:length(c.mon.incr.vec)){
      new.pos <- which(c.mon.incr.vec==c.mon.incr.vec[order(c.mon.incr.vec)][i])
      new.pos <- max(new.pos)
      if(new.pos>max(c.mon.incr.posis)){
        c.mon.incr.posis  <- c(c.mon.incr.posis, new.pos)
      }
    }}
    c.mon.decr.posis  <- which(c.mon.decr.vec==c.mon.decr.vec[order(c.mon.decr.vec)][1])
    if(length(c.mon.decr.vec)>1){
    for(i in 2:length(c.mon.decr.vec)){
      new.pos <- which(c.mon.decr.vec==c.mon.decr.vec[order(c.mon.decr.vec)][i])
      new.pos <- min(new.pos)
      if(new.pos<min(c.mon.decr.posis)){
        c.mon.decr.posis  <- c(c.mon.decr.posis, new.pos)
      }
    }}
    locs <- c(rev(c.mon.decr.posis), c(min.loc-1+c.mon.incr.posis)[-1])
  }
  return(locs)
}
## #############################################################################
## #############################################################################
## Range Function
U.rangeFun <- function(Z.value, BM=FALSE, AM=FALSE, lower.delta=0, upper.delta=0){
  if(BM){
    lower <-c(exp(predict(locfit.m_a.BM, Z.value)-const.a.BM))+lower.delta
    upper <-c(exp(predict(locfit.m_b.BM, Z.value)-const.b.BM))-upper.delta
  }
  if(AM){
    lower <- c(exp(predict(locfit.m_a.AM, Z.value)-const.a.AM))+lower.delta
    upper <- c(exp(predict(locfit.m_b.AM, Z.value)-const.b.AM))-upper.delta
  }
  return(list("lower"=lower,"upper"=upper))
}
## #############################################################################
## #############################################################################

########
## BM ##
########

## Column-wise Max-Values
U.col.max    <- apply(U.mat.BM, 2, max, na.rm=TRUE)
U.col.min    <- apply(U.mat.BM, 2, min, na.rm=TRUE)
##
## Ordering (with increasing temperature)
U.col.max    <- U.col.max[order(apply(Z.mat.BM,2,median,na.rm=TRUE))]
U.col.min    <- U.col.min[order(apply(Z.mat.BM,2,median,na.rm=TRUE))]
##
## Selection of boundary-points
max.posis    <- Myunimod.selector(U.col.max, "Max")
min.posis    <- Myunimod.selector(U.col.min, "Min")
##
Z.orig.vec   <- apply(Z.mat.BM,2,median,na.rm=TRUE)
## y-achsis data for smoothing
## Max-frontier
mymaxbreaks  <- Z.orig.vec[order(Z.orig.vec)][max.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][max.posis]))==0]
mymaxbreaks  <- na.omit(mymaxbreaks)
mymaxyvals   <- U.col.max[max.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][max.posis]))==0]
mymaxyvals   <- na.omit(mymaxyvals)
## Min-frontier
myminbreaks  <- Z.orig.vec[order(Z.orig.vec)][min.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][min.posis]))==0]
myminbreaks  <- na.omit(myminbreaks)
myminyvals   <- U.col.min[min.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][min.posis]))==0]
myminyvals   <- na.omit(myminyvals)
##
## Smoothing
## UpperBound (b(z)) #########################################
if( min(mymaxbreaks) > Z.min.all ){
  mymaxbreaks <- c(Z.min.all, mymaxbreaks)
  mymaxyvals  <- c(mymaxyvals[1], mymaxyvals)
}
if( max(mymaxbreaks) < Z.max.all ){
  mymaxbreaks <- c(mymaxbreaks, Z.max.all)
  mymaxyvals  <- c(mymaxyvals, mymaxyvals[length(mymaxyvals)])
}
if(length(mymaxbreaks)<=5){
  tmp <- approx(x = mymaxbreaks, y = mymaxyvals, xout = seq(min(mymaxbreaks),max(mymaxbreaks),len=6))
  mymaxyvals <- tmp$y
  mymaxbreaks <- tmp$x
}
locfit.m_b.BM  <- smooth.Pspline(x=mymaxbreaks, y=log(mymaxyvals), spar=1e-10)
const.b.BM     <- (-1)*max(log(mymaxyvals)-predict(locfit.m_b.BM, mymaxbreaks))

## LowerBound (a(z)) #########################################
if( min(myminbreaks) > Z.min.all ){
  myminbreaks <- c(Z.min.all, myminbreaks)
  myminyvals  <- c(myminyvals[1], myminyvals)
}
if( max(myminbreaks) < Z.max.all ){
  myminbreaks <- c(myminbreaks, Z.max.all)
  myminyvals  <- c(myminyvals, myminyvals[length(myminyvals)])
}
if(length(myminbreaks)<=5){
  tmp <- approx(x = myminbreaks, y = myminyvals, xout = seq(min(myminbreaks),max(myminbreaks),len=6))
  myminyvals <- tmp$y
  myminbreaks <- tmp$x
}
locfit.m_a.BM          <- smooth.Pspline(x=myminbreaks, y=log(myminyvals), spar=1e-10)
const.a.BM             <- (-1)*min(log(myminyvals)-predict(locfit.m_a.BM, myminbreaks))


rm(U.col.max, U.col.min, 
  max.posis, min.posis, 
  Z.orig.vec, 
  mymaxbreaks, mymaxyvals, 
  myminbreaks, myminyvals)


########
## AM ##
########


## Column-wise Max-Values
U.col.max    <- apply(U.mat.AM, 2, max, na.rm=TRUE)
U.col.min    <- apply(U.mat.AM, 2, min, na.rm=TRUE)
##
## Ordering (with increasing temperature)
U.col.max    <- U.col.max[order(apply(Z.mat.AM,2,median,na.rm=TRUE))]
U.col.min    <- U.col.min[order(apply(Z.mat.AM,2,median,na.rm=TRUE))]
##
##Range.vec    <- Range.vec[order(apply(Z.mat.AM,2,median,na.rm=TRUE))]
## Selection of boundary-points
max.posis    <- Myunimod.selector(U.col.max, "Max")
min.posis    <- Myunimod.selector(U.col.min, "Min")
##
Z.orig.vec   <- apply(Z.mat.AM,2,median,na.rm=TRUE)
## y-achsis data for smoothing
## Max-frontier
mymaxbreaks  <- Z.orig.vec[order(Z.orig.vec)][max.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][max.posis]))==0]
mymaxbreaks  <- na.omit(mymaxbreaks)
mymaxyvals   <- U.col.max[max.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][max.posis]))==0]
mymaxyvals   <- na.omit(mymaxyvals)
## Min-frontier
myminbreaks  <- Z.orig.vec[order(Z.orig.vec)][min.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][min.posis]))==0]
myminbreaks  <- na.omit(myminbreaks)
myminyvals   <- U.col.min[min.posis][!c(1,diff(Z.orig.vec[order(Z.orig.vec)][min.posis]))==0]
myminyvals   <- na.omit(myminyvals)
##
## Smoothing
## UpperBound (b(z)) #########################################
if( min(mymaxbreaks) > Z.min.all ){
  mymaxbreaks <- c(Z.min.all, mymaxbreaks)
  mymaxyvals  <- c(mymaxyvals[1], mymaxyvals)
}
if( max(mymaxbreaks) < Z.max.all ){
  mymaxbreaks <- c(mymaxbreaks, Z.max.all)
  mymaxyvals  <- c(mymaxyvals, mymaxyvals[length(mymaxyvals)])
}
if(length(mymaxbreaks)<=5){
  tmp <- approx(x = mymaxbreaks, y = mymaxyvals, xout = seq(min(mymaxbreaks),max(mymaxbreaks),len=6))
  mymaxyvals <- tmp$y
  mymaxbreaks <- tmp$x
}

locfit.m_b.AM  <- smooth.Pspline(x=mymaxbreaks, y=log(mymaxyvals), spar = 1e-10)
const.b.AM     <- (-1)*max(log(mymaxyvals)-predict(locfit.m_b.AM, mymaxbreaks))

## LowerBound (a(z)) #########################################
if( min(myminbreaks) > Z.min.all ){
  myminbreaks <- c(Z.min.all, myminbreaks)
  myminyvals  <- c(myminyvals[1], myminyvals)
}
if( max(myminbreaks) < Z.max.all ){
  myminbreaks <- c(myminbreaks, Z.max.all)
  myminyvals  <- c(myminyvals, myminyvals[length(myminyvals)])
}
if(length(myminbreaks)<=5){
  tmp <- approx(x = myminbreaks, y = myminyvals, xout = seq(min(myminbreaks),max(myminbreaks),len=6))
  myminyvals <- tmp$y
  myminbreaks <- tmp$x
}
locfit.m_a.AM          <- smooth.Pspline(x=myminbreaks, y=log(myminyvals), spar=1/10)
const.a.AM             <- (-1)*min(log(myminyvals)-predict(locfit.m_a.AM, myminbreaks))


rm(U.col.max, U.col.min, 
  max.posis, min.posis, 
  Z.orig.vec, 
  mymaxbreaks, mymaxyvals, 
  myminbreaks, myminyvals)