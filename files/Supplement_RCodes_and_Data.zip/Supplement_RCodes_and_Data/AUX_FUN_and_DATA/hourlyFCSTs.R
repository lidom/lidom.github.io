myhourlyFCSTs <- function(n, T_cut, method=c("persi","ideal")){

  method   <- match.arg(method)
  tmp.y    <- NULL
  tmp.yhat <- NULL
  tmp.CIu  <- NULL
  tmp.CIl  <- NULL
  
  loop.end <- c(T-T_cut-n)
  if(method=="persi"){
    print(method)
    for(i in 1:loop.end){
      ## updated time series:	
      ts.1 <- ts(ts.beta1[1:T_cut])
      ts.2 <- ts(ts.beta2[1:T_cut])
      ## univariate TS-Models:
      model1  <- try(arima(ts.1, order=pdq1, seasonal=list(order=PDQ1, period=5), method="ML"))
      if(is.character(model1)){
        model1  <-   arima(ts.1, order=pdq1, seasonal=list(order=PDQ1, period=5))
      }
      model2  <- try(arima(ts.2, order=pdq2, seasonal=list(order=PDQ2, period=5), method="ML"))
      if(is.character(model2)){
        model2  <-   arima(ts.2, order=pdq2, seasonal=list(order=PDQ2, period=5))
      }      
      ## "selector": Last Observed day of the learning sample
      selector <- T_cut
      while(is.na(ord.mat.withNAs[1,selector])){
        selector <- selector-1
      }
      tmp.y      <- c(tmp.y,
                      if(is.na(Dates.withNAs[c(T_cut+n)])){
                        rep(NA,24)
                      }else{
                        Y.mat.orig.withNAs[,c(T_cut+n)][!is.na(Y.mat.orig.withNAs[,c(T_cut+n)])]
                      })
      tmp.yhat   <- c(tmp.yhat,
                      if(is.na(Dates.withNAs[c(T_cut+n)])){
                        rep(NA,24)
                      }else{
                      c(c(predict(model1, n.ahead=n)$pred)[n] *sgn1*
                        c(predict(e.fun.hat.rot, 
                                  U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                  )[,1]) +
                        c(predict(model2, n.ahead=n)$pred)[n] *sgn2*
                        c(predict(e.fun.hat.rot, 
                                  U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                  )[,2]))})
      ##
      tmp.se1    <- c(predict(model1, n.ahead=n)$se)[n]
      tmp.se2    <- c(predict(model2, n.ahead=n)$se)[n]
	
      beta1.CI_1   <- c(c(predict(model1, n.ahead=n)$pred)[n] * sgn1 + 1.96 * tmp.se1)	
	  beta1.CI_2   <- c(c(predict(model1, n.ahead=n)$pred)[n] * sgn1 - 1.96 * tmp.se1)
	  beta1.CI_u   <- ifelse(beta1.CI_1>c(predict(model1, n.ahead=n)$pred)[n] *sgn1, beta1.CI_1, beta1.CI_2)
	  beta1.CI_l   <- ifelse(beta1.CI_1<c(predict(model1, n.ahead=n)$pred)[n] *sgn1, beta1.CI_1, beta1.CI_2)
	  ##
	  beta2.CI_1   <- c(c(predict(model2, n.ahead=n)$pred)[n] * sgn2 + 1.96 * tmp.se2)	
	  beta2.CI_2   <- c(c(predict(model2, n.ahead=n)$pred)[n] * sgn2 - 1.96 * tmp.se2)
	  beta2.CI_u   <- ifelse(beta2.CI_1<c(predict(model2, n.ahead=n)$pred)[n] *sgn2, beta2.CI_1, beta2.CI_2)
	  beta2.CI_l   <- ifelse(beta2.CI_1>c(predict(model2, n.ahead=n)$pred)[n] *sgn2, beta2.CI_1, beta2.CI_2)

      ##
      tmp.CIu   <- c(tmp.CIu,
                     if(is.na(Dates.withNAs[c(T_cut+n)])){
                       rep(NA,24)
                     }else{
                     c(beta1.CI_u *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                 )[,1]) +
                       beta2.CI_u *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                 )[,2]))})
      ##
      tmp.CIl   <- c(tmp.CIl,
                     if(is.na(Dates.withNAs[c(T_cut+n)])){
                       rep(NA,24)
                     }else{
                     c(beta1.CI_l *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                 )[,1]) +
                       beta2.CI_l *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(selector)][!is.na(U.mat.orig.withNAs[,c(selector)])]
                                 )[,2]))})
      ##
      T_cut  <- T_cut+1
    }
  }
  if(method=="ideal"){
    print(method)
    for(i in 1:loop.end){
      ts.1 <- ts(ts.beta1[1:T_cut])
      ts.2 <- ts(ts.beta2[1:T_cut])
      ## univariate TS-Models:
      model1  <- arima(ts.1, order=pdq1, seasonal=list(order=PDQ1, period=5))
      model2  <- arima(ts.2, order=pdq2, seasonal=list(order=PDQ2, period=5))
      
      tmp.y      <- c(tmp.y,
                      if(is.na(Dates.withNAs[c(T_cut+n)])){
                        rep(NA,24)
                      }else{
                        Y.mat.orig.withNAs[,c(T_cut+n)][!is.na(Y.mat.orig.withNAs[,c(T_cut+n)])]})
      tmp.yhat   <- c(tmp.yhat,
                      if(is.na(Dates.withNAs[c(T_cut+n)])){
                        rep(NA,24)
                      }else{
                      c(
                        c(predict(model1, n.ahead=n)$pred)[n] *sgn1*
                        c(predict(e.fun.hat.rot, 
                                  U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                  )[,1]) +
                        c(predict(model2, n.ahead=n)$pred)[n] *sgn2*
                        c(predict(e.fun.hat.rot, 
                                  U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                  )[,2]))})
      ##
      tmp.se1    <- c(predict(model1, n.ahead=n)$se)[n]
      tmp.se2    <- c(predict(model2, n.ahead=n)$se)[n]
	  ##
	  beta1.CI_1   <- c(c(predict(model1, n.ahead=n)$pred)[n] * sgn1 + 1.96 * tmp.se1)	
	  beta1.CI_2   <- c(c(predict(model1, n.ahead=n)$pred)[n] * sgn1 - 1.96 * tmp.se1)
	  beta1.CI_u   <- ifelse(beta1.CI_1>c(predict(model1, n.ahead=n)$pred)[n] *sgn1, beta1.CI_1, beta1.CI_2)
	  beta1.CI_l   <- ifelse(beta1.CI_1<c(predict(model1, n.ahead=n)$pred)[n] *sgn1, beta1.CI_1, beta1.CI_2)
	  ##
	  beta2.CI_1   <- c(c(predict(model2, n.ahead=n)$pred)[n] * sgn2 + 1.96 * tmp.se2)	
	  beta2.CI_2   <- c(c(predict(model2, n.ahead=n)$pred)[n] * sgn2 - 1.96 * tmp.se2)
	  beta2.CI_u   <- ifelse(beta2.CI_1<c(predict(model2, n.ahead=n)$pred)[n] *sgn2, beta2.CI_1, beta2.CI_2)
	  beta2.CI_l   <- ifelse(beta2.CI_1>c(predict(model2, n.ahead=n)$pred)[n] *sgn2, beta2.CI_1, beta2.CI_2)
      ##
      tmp.CIu   <- c(tmp.CIu,
                     if(is.na(Dates.withNAs[c(T_cut+n)])){
                       rep(NA,24)
                     }else{
                     c(
                       beta1.CI_u *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                 )[,1]) +
                       beta2.CI_u *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                 )[,2]))})
      ##
      tmp.CIl   <- c(tmp.CIl,
                     if(is.na(Dates.withNAs[c(T_cut+n)])){
                       rep(NA,24)
                     }else{
                     c(
                       beta1.CI_l *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                 )[,1]) +
                       beta2.CI_l *
                       c(predict(e.fun.hat.rot, 
                                 U.mat.orig.withNAs[,c(T_cut+n)][!is.na(U.mat.orig.withNAs[,c(T_cut+n)])]
                                 )[,2]))})
      ##
      T_cut  <- T_cut+1
    }
  }
  ## Return-Object
  return.obj      <- vector("list",4)
  return.obj$y    <- tmp.y
  return.obj$yhat <- tmp.yhat
  return.obj$CIu  <- tmp.CIu
  return.obj$CIl  <- tmp.CIl
  return(return.obj)
}
