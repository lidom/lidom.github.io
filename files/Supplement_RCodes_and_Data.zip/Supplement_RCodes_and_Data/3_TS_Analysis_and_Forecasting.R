rm(list=ls())
##################################
## TS Analysis and Forecasting  ##
##################################

###############################
require(pspline)             ##
require(urca)                ##
require(vars)                ##
require(fUnitRoots)          ##
require(tseries)             ##
require(locfit)              ##
load("VARIMAX.RData")        ##
###############################

DUMMYFEIER.withoutSASU <- DUMMYFEIER[!c(as.logical(DUMMYSU)|as.logical(DUMMYSA))]

## Filling in NA's for Holydays (SARIMA estimation procedure considers NA-values)
T                   <- length(DUMMYFEIER.withoutSASU)
ts.beta1            <- numeric(T)
ts.beta2            <- numeric(T)
Dates.withNAs       <- numeric(T)
Y.mat.orig.withNAs  <- matrix(NA,24,T)
U.mat.orig.withNAs  <- matrix(NA,24,T)
ord.mat.withNAs     <- matrix(NA,24,T)
i        <- 1
for(t in 1:T){
  if(DUMMYFEIER.withoutSASU[t]==0){
    ts.beta1[t]             <- scores.rot[  1,i]
    ts.beta2[t]             <- scores.rot[  2,i]
    Dates.withNAs[t]        <- ord.RL.Dates[1,i]
    Y.mat.orig.withNAs[,t]  <- Y.mat.orig[ ,i]
    U.mat.orig.withNAs[,t]  <- U.mat.orig[,i]
    ord.mat.withNAs[,t]     <- ord.mat[    ,i]
    i                       <- i+1
  }else{
    ts.beta1[t]             <- NA
    ts.beta2[t]             <- NA
    Dates.withNAs[t]        <- NA
    Y.mat.orig.withNAs[,t]  <- NA
    U.mat.orig.withNAs[,t]  <- NA
    ord.mat.withNAs[,t]     <- NA
  }
}

#################################################################################
## Univariate time series analysis:                                            ##
## Validation of assumptions on projection parameters and random domains       ##
#################################################################################

## Declare Scores as ts-objects
ts.beta1 <- ts(ts.beta1* sgn1)
ts.beta2 <- ts(ts.beta2* sgn2)
## Plot of Scores
par(mfrow=c(2,1))
plot(ts.beta1);plot(ts.beta2)

## #######################################
## ## KPSS-Tests: H0: "Stationarity"    ##
## #######################################

## H0:"Stationay" can be rejected  for (beta_t1) and (beta_t2) at sign-level 0.05
kpss.test(ts.beta1, null="Trend", lshort=TRUE);
kpss.test(ts.beta1, null="Level", lshort=TRUE);
kpss.test(ts.beta2, null="Trend", lshort=TRUE);
kpss.test(ts.beta2, null="Level", lshort=TRUE);
kpss.test(ts.beta1, null="Trend", lshort=FALSE);
kpss.test(ts.beta1, null="Level", lshort=FALSE);
kpss.test(ts.beta2, null="Trend", lshort=FALSE);
kpss.test(ts.beta2, null="Level", lshort=FALSE);

## first differences of scores (beta_{t1}) and (beta_{t2}) and plot
ts.beta1d <- diff(ts.beta1)
ts.beta2d <- diff(ts.beta2)
par(mfrow=c(2,1))
plot(ts.beta1d)
plot(ts.beta2d)

# acf and pacf of differenced time series of scores
par(mfrow=c(2,2))
acf( ts.beta1d, na.action=na.pass)
pacf(ts.beta1d, na.action=na.pass)
acf( ts.beta2d, na.action=na.pass)
pacf(ts.beta2d, na.action=na.pass)


## H0:"Non-Stationary" can be rejected for (beta_t1) and (beta_t2) at sign-level <0.05
## (beta_t1)
urdf.1 <- ur.df(ts.beta1d[!is.na(ts.beta1d)], type="none", lags=3)  
summary(urdf.1)
## t and F-type Teststatistics with critical values
urdf.1@teststat  # HO: "There is a unit root (tau==0)" 
urdf.1@cval

## (beta_t2)
urdf.2 <- ur.df(ts.beta2d[!is.na(ts.beta2d)], type="none", lags=2)  
summary(urdf.2)
## t and F-type Teststatistics with critical values
urdf.2@teststat  # HO: "There is a unit root (tau==0)" 
urdf.2@cval
## =================================================================================


#####################################################
## Fit an ARIMA-model for (beta_t1) and (beta_t2)  ##
#####################################################

############################
## Model 1 (First Scores) ##
############################

## Last day in 2007
Dates.withNAs[521] # "NA", because of X-mas holidays
######################
T_cut        <- 521 ##
######################

ts.beta1c <- ts(ts.beta1[1:T_cut])

## first differences (Standard & Seasonal)
ts.beta1cd <- diff(diff(ts.beta1c),lag=5)

## check acf and pacf for (beta_t1)
par(mfrow=c(1,2))
acf( ts.beta1cd, lag.max=40, na.action = na.pass)
pacf(ts.beta1cd, lag.max=40, na.action = na.pass)
par(mfrow=c(1,1))

## Different SARIMA-Models  for (beta_t1)::
pdq1     <- c(0,1,6)
PDQ1     <- c(0,1,1)
pdq1.1   <- c(6,1,0)
PDQ1.1   <- c(4,1,0)
pdq1.2   <- c(6,1,1)
PDQ1.2   <- c(1,1,1)

## Check Different Models:
for(subsets in c(0.75, 1)){
try(model1   <- arima(ts.beta1c[1:floor(T_cut*subsets)], order=pdq1,   seasonal=list(order=PDQ1,   period=5), method ="ML"))
## diagniostics
try(plot(density(model1$residuals, na.rm=TRUE),main="1"))
try(tsdiag(model1, gof.lag=40)); model1$aic

try(model1.1 <- arima(ts.beta1c[1:floor(T_cut*subsets)], order=pdq1.1, seasonal=list(order=PDQ1.1, period=5), method ="ML"))
## diagniostics
try(plot(density(model1.1$residuals, na.rm=TRUE),main="2"))
try(tsdiag(model1.1, gof.lag=40)); model1.1$aic

try(model1.2 <- arima(ts.beta1c[1:floor(T_cut*subsets)], order=pdq1.2, seasonal=list(order=PDQ1.2, period=5), method ="ML"))
## diagniostics
try(plot(density(model1.2$residuals, na.rm=TRUE),main="3"))
try(tsdiag(model1.2, gof.lag=40)); model1.2$aic

## Model-Comparision
print(order(c(model1$aic, model1.1$aic, model1.2$aic))[1])
}


#############################
## Model 2 (Second Scores) ##
#############################

ts.beta2c <- ts(ts.beta2[1:T_cut])
plot(ts.beta2c)

# first differences
ts.beta2cd <- diff(diff(ts.beta2c),lag=5)

## check acf and pacf for (beta_t2)
par(mfrow=c(1,2))
acf( ts.beta2cd, lag.max=40, na.action = na.pass)
pacf(ts.beta2cd, lag.max=40, na.action = na.pass)
par(mfrow=c(1,1))

## Different SARIMA-Models for (beta_t2):
pdq2     <- c(0,1,6)
PDQ2     <- c(0,1,1)
pdq2.1   <- c(6,1,0)
PDQ2.1   <- c(4,1,0)
pdq2.2   <- c(6,1,1)
PDQ2.2   <- c(1,1,1)

## Check Different Models:
for(subsets in c(0.75, 1)){
try(model2   <- arima(ts.beta2c[1:floor(T_cut*subsets)], order=pdq2,   seasonal=list(order=PDQ2,   period=5), method ="ML"))
## diagniostics
try(plot(density(model2$residuals, na.rm=TRUE),main="1"))
try(tsdiag(model2, gof.lag=40)); model2$aic

try(model2.1 <- arima(ts.beta2c[1:floor(T_cut*subsets)], order=pdq2.1, seasonal=list(order=PDQ2.1, period=5), method ="ML"))
## diagniostics
try(plot(density(model2.1$residuals, na.rm=TRUE),main="2"))
try(tsdiag(model2.1, gof.lag=40)); model2.1$aic

try(model2.2 <- arima(ts.beta2c[1:floor(T_cut*subsets)], order=pdq2.2, seasonal=list(order=PDQ2.2, period=5), method ="ML"))
## diagniostics
try(plot(density(model2.2$residuals, na.rm=TRUE),main="3"))
try(tsdiag(model2.2, gof.lag=40)); model2.2$aic

## Model-Comparision
print(order(c(model2$aic, model2.1$aic, model2.2$aic))[1])
}


## TS-Model for First Scores
model1 <- arima(ts.beta1c, order=pdq1, seasonal=list(order=PDQ1, period=5), method ="ML")
## TS-Model for Second Scores
model2 <- arima(ts.beta2c, order=pdq2, seasonal=list(order=PDQ2, period=5), method ="ML")


## Inner Samples and Outer Samples:
ts.beta1c <- ts(ts.beta1[1:T_cut])
ts.beta2c <- ts(ts.beta2[1:T_cut])
ts.beta1c.outer <- ts(ts.beta1[c(T_cut+1):T])
ts.beta2c.outer <- ts(ts.beta2[c(T_cut+1):T])

###############################################
## Total Forecast-Range                       #
T-T_cut                                       #
                                              #
## Small Forecasting-DEMO                     #
## n-days ahead forecast                      #
n         <- 6                                #
# forecast                                    #
predict(model1, n.ahead=n)$pred[n]            #
# actual value                                #
ts.beta1c.outer[n]                            #
                                              #
# forecast                                    #
predict(model2, n.ahead=n)$pred[n]            #
# actual value                                #
ts.beta2c.outer[n]                            #
###############################################

###########################################################################
## Computation of hourly electricity spot prices                         ##
## as well as the conditional 95%-Confidence Intervalls                  ##
## This takes some computation time!:                                    ##
###########################################################################
source("AUX_FUN_and_DATA/hourlyFCSTs.R")                                 ##
n <- 1 # n-day ahead forecast                                            ##
fcst.data.1.persi <- myhourlyFCSTs(n=n, T_cut=T_cut, method="persi")     ## 
fcst.data.1.ideal <- myhourlyFCSTs(n=n, T_cut=T_cut, method="ideal")     ## 
###########################################################################

## Reading out the above Computations: ####################################
l.1.persi      <- fcst.data.1.persi$CIl
u.1.persi      <- fcst.data.1.persi$CIu
if(mean(u.1.persi,na.rm=TRUE) < mean(l.1.persi,na.rm=TRUE)){
	tmp.CI <- l.1.persi; l.1.persi <- u.1.persi; u.1.persi <- tmp.CI
}
x.1            <- fcst.data.1.persi$y
xhat.1.persi   <- fcst.data.1.persi$yhat
l.1.ideal       <- fcst.data.1.ideal$CIl
u.1.ideal       <- fcst.data.1.ideal$CIu
xhat.1.ideal    <- fcst.data.1.ideal$yhat
if(mean(u.1.ideal,na.rm=TRUE) < mean(l.1.ideal,na.rm=TRUE)){
	tmp.CI <- l.1.ideal; l.1.ideal <- u.1.ideal; u.1.ideal <- tmp.CI
}
## End of Reading out #####################################################


#######################
## Plot of Figure 7  ##
#######################

## Plot Spot-Prices vs. Fcst-Spot-Prices (1 Days ahead)
start.day <- 19 
## Selection of the Corresponding Hours:
slct.1 <- (((start.day-1)*24)+1):(((start.day-1)*24)+(24))

par(mfrow=c(1,1))
scl     <- 1
scl.axs <- 1.3
scl.lab <- 1.3
Dates.withNAs[(T_cut+start.day)]

plot.range <- range(x.1[slct.1],xhat.1.ideal[ slct.1],u.1.ideal[ slct.1],l.1.ideal[ slct.1],
                    x.1[slct.1],xhat.1.persi[slct.1],u.1.persi[slct.1],l.1.persi[slct.1])

plot(y=x.1[slct.1], x=c(U.mat.orig.withNAs[,(T_cut+start.day)]), ylim=plot.range,
     col="white", main="1 Day Ahead Forecast of a Price-Demand Function",
     ylab="EUR/MWh",
     xlab="MW",cex=scl, cex.lab=scl.lab, cex.axis=scl.axs, cex.main=scl.axs,type="l")

xx <- c(    c(U.mat.orig.withNAs[,(T_cut+start.day)]), 
	    rev(c(U.mat.orig.withNAs[,(T_cut+start.day)])))
yy <- c(    c(matrix(u.1.ideal,nrow=24)[,(start.day)]),
        rev(c(matrix(l.1.ideal,nrow=24)[,(start.day)])))
polygon(xx, yy, col="gray", border = NA)


points(y=x.1[slct.1],       x=c(U.mat.orig.withNAs[,(T_cut+start.day)]))
lines(y=matrix(xhat.1.ideal, nrow=24)[,(start.day)], x=c(U.mat.orig.withNAs[,(T_cut+start.day)]), lty=2)
dev.off()

## Same Plot as above but with hourly order:

####################################
## Plot of Figure 8 (left panel)  ##
####################################
## for re-ordering into hourly sequences:
(ordr          <- order(ord.mat.withNAs[,(T_cut+start.day)]))
(ordr.persi    <- order(ord.mat.withNAs[,(T_cut+start.day-1)]))

scl     <- 1
scl.axs <- 1.3
scl.lab <- 1.3

par(mfrow=c(1,1))
plot.range <- range(x.1[slct.1],xhat.1.ideal[ slct.1],u.1.ideal[ slct.1],l.1.ideal[ slct.1],
                    x.1[slct.1],xhat.1.persi[slct.1],u.1.persi[slct.1],l.1.persi[slct.1])

plot(x.1[slct.1][ordr], ylim=plot.range,cex=scl, cex.lab=scl.lab, cex.axis=scl.axs, cex.main=scl.axs,
        col="white", main="1 Day Ahead\n(Ideal Demand Forecast)",ylab="EUR/MWh",
        xlab="Hours ",type="l")
	
xx <- c(1:(24),(24):1)
yy <- c(    c(matrix(u.1.ideal,nrow=24)[,(start.day)][ordr]),
        rev(c(matrix(l.1.ideal,nrow=24)[,(start.day)][ordr])))	
polygon(xx, yy, col="gray", border = NA)
points(y=x.1[slct.1][ordr],         x=c(1:(24)))
lines(y=matrix(xhat.1.ideal, nrow=24)[,(start.day)][ordr], x=c(1:(24)), lty=2)
dev.off()

#####################################
## Plot of Figure 8 (right panel)  ##
#####################################

plot(x.1[slct.1][ordr], ylim=plot.range,cex=scl, cex.lab=scl.lab, cex.axis=scl.axs, cex.main=scl.axs,
        col="white", main="1 Day Ahead\n(Persistence Demand Forecast)",ylab="EUR/MWh",
        xlab="Hours ",type="l")
xx <- c(1:(24),(24):1)
yy <- c(    c(matrix(u.1.persi,nrow=24)[,(start.day)][ordr.persi]),
        rev(c(matrix(l.1.persi,nrow=24)[,(start.day)][ordr.persi])))	
polygon(xx, yy, col="gray", border = NA)
points(y=x.1[slct.1][ordr],         x=c(1:(24)))
lines(y=matrix(xhat.1.persi, nrow=24)[,(start.day)][ordr.persi], x=c(1:(24)), lty=2)
par(mfrow=c(1,1))
dev.off()






