## Preparation of data:
## \tilde{X}_t^\ast(u_{ti})*\tilde{X}_t^\ast(u_{tj})
## for local linear surface smoothing
## (see equation 10)

G.ar            <- array(NA, dim=c(N, N, T))
diag_only       <- matrix(NA,N,N)
diag(diag_only) <- rep(1,N)
diag_rm         <- matrix(1,N,N)+diag(NA, N, N)

for(i in 1:T){
  G.ar[,,i]   <- (X.tilde.mat[,i] %*% t(X.tilde.mat[,i])) * diag_rm
}

U.1        <- U.mat[rep(1:N, N),     ]
U.2        <- U.mat[rep(1:N, each=N),]
U.od.ar    <- array(dim=c(N,N,T))
U.1.rmd.ar <- array(dim=c(N,N,T))
U.2.rmd.ar <- array(dim=c(N,N,T))

for(i in 1:T){
  ## N*N-vec 2 NxN-mat
  U.od.ar[,,i]    <- U.1[,i]
  U.1.rmd.ar[,,i] <- U.1[,i]
  U.2.rmd.ar[,,i] <- U.2[,i]
}

## Set outer cols/rows (and diagonal) to NA
for(i in 1:T){
  U.1.rmd.ar[,,i] <- U.1.rmd.ar[,,i] * diag_rm
  U.2.rmd.ar[,,i] <- U.2.rmd.ar[,,i] * diag_rm
  U.od.ar[,,i]    <- U.od.ar[,,i]    * diag_only
}
U_i.rmd     <- as.vector(U.1.rmd.ar )
U_j.rmd     <- as.vector(U.2.rmd.ar )
G.vec       <- as.vector(G.ar)
