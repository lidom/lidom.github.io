par(mfrow=c(2,2))
plot(x=seq(0, 1, length=50),
     y=rep(0, length=50),
     col="red", type="l", main=paste("Eigenfunction 1 \n", round(var.shares[1]*100, digits=2),"%"),
     ylab="EUR/MWh", xlab="Adjusted Demand (MW)",
     ylim=range(c(
        3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,1],
       -3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,1])
       ))
lines(x=seq(0, 1, length=50),
      y=(3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,1]))
lines(x=seq(0, 1, length=50),
      y=(-3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,1]))

plot(x=seq(0, 1, length=50),
     y=rep(0, length=50),
     col="red", type="l", main=paste("Eigenfunction 2 \n", round(var.shares[2]*100, digits=2),"%"),
     ylab="EUR/MWh", xlab="Adjusted Demand (MW)",
     ylim=range(c(
        3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,2],
       -3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,2])
       ))
lines(x=seq(0, 1, length=50),
      y=(3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,2]))
lines(x=seq(0, 1, length=50),
      y=(-3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,2]))


plot(x=seq(0, 1, length=50),
     y=rep(0, length=50),
     col="red", type="l", main=paste("Eigenfunction 3 \n", round(var.shares[3]*100, digits=2),"%"),
     ylab="EUR/MWh", xlab="Adjusted Demand (MW)",
     ylim=range(c(
        3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,3],
       -3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,3])
       ))
lines(x=seq(0, 1, length=50),
      y=(3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,3]))
lines(x=seq(0, 1, length=50),
      y=(-3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,3]))


plot(x=seq(0, 1, length=50),
     y=rep(0, length=50),
     col="red", type="l", main=paste("Eigenfunction 4 \n", round(var.shares[4]*100, digits=2),"%"),
     ylab="EUR/MWh", xlab="Adjusted Demand (MW)",
     ylim=range(c(
        3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,4],
       -3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,4])
       ))
lines(x=seq(0, 1, length=50),
      y=(3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,4]))
lines(x=seq(0, 1, length=50),
      y=(-3*predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE),max(U.mat, na.rm=TRUE),length=50))[,4]))
par(mfrow=c(1,1))
