## #####################
## Mean
## #####################

YUZ.bigmat     <- cbind(Y.vec, U.vec, Z.vec)
YUZ.bigmat     <- as.big.matrix(YUZ.bigmat)

## ##########################
## GCV-Bandwidth Selection 
## ##########################
## mean function
GCV.grid.len <- 10
GCV.mat      <- matrix(NA,GCV.grid.len,GCV.grid.len)
hu.seq       <- seq(0.15, 1.0, len=GCV.grid.len) # smaller values than 0.12 lead to local sparseness
hz.seq       <- seq(0.15, 1.0 ,len=GCV.grid.len) # 
##
cat("Now: GCV-mean\n")
for(i in 1:GCV.grid.len){
  for(j in 1:GCV.grid.len){
    GCV.mat[i,j]  <- KLL_mean_fun(YUZ.bigmat   = YUZ.bigmat,
                                  hu           = hu.seq[i],
                                  hz           = hz.seq[j],
                                  binning      = TRUE,
                                  eval.at.data = TRUE,
                                  bin.grid.len = 100,
                                  kernel       = kernel)[['GCV']]
  }
}
GCV.loc.min <- which(GCV.mat == min(GCV.mat), arr.ind = TRUE)
hu.mean.GCV <- hu.seq[GCV.loc.min[1]] 
hz.mean.GCV <- hz.seq[GCV.loc.min[2]]


## 2nd derivative of mean function
GCV.grid.len <- 10
GCV.DDu.mat  <- matrix(NA,GCV.grid.len,GCV.grid.len)
GCV.DDz.mat  <- matrix(NA,GCV.grid.len,GCV.grid.len)
hDDu.seq     <- seq(0.8, 3.0,len=GCV.grid.len)
hDDz.seq     <- seq(0.8, 3.0,len=GCV.grid.len)
##
cat("Now: GCV-meanDD\n")
for(i in 1:GCV.grid.len){
  for(j in 1:GCV.grid.len){
    Result.tmp <- KLL_mean_fun(YUZ.bigmat   = YUZ.bigmat,
                              hu           = hDDu.seq[i],
                              hz           = hDDz.seq[j],
                              binning      = TRUE,
                              eval.at.data = TRUE,
                              bin.grid.len = 100,
                              kernel       = kernel,
                              DD.est       = TRUE)
    GCV.DDu.mat[i,j] <- Result.tmp[['GCV.DDu']]
    GCV.DDz.mat[i,j] <- Result.tmp[['GCV.DDz']]
  }
}
GCV.DDu.loc.min  <- which(GCV.DDu.mat == min(GCV.DDu.mat), arr.ind = TRUE)
hDDu.u.mean.GCV  <- hDDu.seq[GCV.DDu.loc.min[1]] 
hDDu.z.mean.GCV  <- hDDz.seq[GCV.DDu.loc.min[2]]
##
GCV.DDz.loc.min  <- which(GCV.DDz.mat == min(GCV.DDz.mat), arr.ind = TRUE)
hDDz.u.mean.GCV  <- hDDu.seq[GCV.DDz.loc.min[1]] 
hDDz.z.mean.GCV  <- hDDz.seq[GCV.DDz.loc.min[2]]

## #####################################################
## Estimating the mean function ########################
## #####################################################    

## mean and bias estimation @ test-points:
mean.TP.hat     <- rep(NA, length(u.TP))
mean.DDu.TP.hat <- rep(NA, length(u.TP))
mean.DDz.TP.hat <- rep(NA, length(u.TP))
##
cat("Now: Estimating the mean function\n")
for(i in 1:length(u.TP)){
  ## Mean
  mean.TP.hat[i] <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                                  hu         = hu.mean.GCV,
                                  hz         = hz.mean.GCV,
                                  u.eval     = u.TP[i],
                                  z.eval     = z.TP[i],
                                  kernel     = kernel)[['y.hat']]
  ## Bias
  mean.DDu.TP.hat[i] <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                                     hu         = hDDu.u.mean.GCV,
                                     hz         = hDDu.z.mean.GCV,
                                     u.eval     = u.TP[i],
                                     z.eval     = z.TP[i],
                                     kernel     = kernel,
                                     DD.est     = TRUE)[['y.hat.DDu']]
  mean.DDz.TP.hat[i] <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                                     hu         = hDDz.u.mean.GCV,
                                     hz         = hDDz.z.mean.GCV,
                                     u.eval     = u.TP[i],
                                     z.eval     = z.TP[i],
                                     kernel     = kernel,
                                     DD.est     = TRUE)[['y.hat.DDz']]
  ## Feedback:
  cat("Progress (Mean & Bias @Test-Points) =",round((i/length(u.TP))*100,digits=0),"%\n")
}

## mean estimation @ observed points:
mean.hat <- rep(NA,length(Y.vec))
for(i in 1:length(Y.vec)){
  ## Mean
  mean.hat[i] <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                                  hu         = hu.mean.GCV,
                                  hz         = hz.mean.GCV,
                                  u.eval     = U.vec[i],
                                  z.eval     = Z.vec[i],
                                  kernel     = kernel)[['y.hat']]
  ## Feedback:
  if( round((i/length(Y.vec))*100,digits=0) %% 10 == 0){
  cat("Progress (Mean @obs) =",round((i/length(Y.vec))*100,digits=0),"%\n")
  }
}

## #####################################
## Computing the 'raw covariates'     ##
## #####################################

Y.jx    <- rep(NA,(m^2)*n)
Y.xk    <- rep(NA,(m^2)*n)
U.jx    <- rep(NA,(m^2)*n)
U.xk    <- rep(NA,(m^2)*n)
##
Z.xx    <- rep(NA,(m^2)*n)
##
ND.pos.jk    <- rep(NA,(m^2)*n)
##
for(i in 1:n){#i<-1
  Y.jx[(1+(i-1)*(m^2)):(i*(m^2))] <- rep(Y.mat[,i],times=m)
  Y.xk[(1+(i-1)*(m^2)):(i*(m^2))] <- rep(Y.mat[,i], each=m)
  ##
  U.jx[(1+(i-1)*(m^2)):(i*(m^2))] <- rep(U.mat[,i],times=m)
  U.xk[(1+(i-1)*(m^2)):(i*(m^2))] <- rep(U.mat[,i], each=m)
  ##
  Z.xx[(1+(i-1)*(m^2)):(i*(m^2))] <- rep(Z.mat[,i],times=m)
  ##
  tmp                       <- matrix(1,m,m)
  diag(tmp)                 <- NA
  ## Save non-nosy off-diagonal values (noisy diag-values set to NAs)
  ND.pos.jk[(1+(i-1)*(m^2)):(i*(m^2))] <- c(tmp)
}
## if 'j==k': NA (noisy diagonal positions)
ND.pos <- is.na(ND.pos.jk)

##
C.jk  <- rep(NA, length(Y.jx))
print <- 0
cat("Now: Computing the 'raw covariates'\n")
for(i in 1:length(Y.jx)){
  C.jk[i] <- (Y.jx[i] -  KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                                      hu         = hu.mean.GCV,
                                      hz         = hz.mean.GCV,
                                      u.eval     = U.jx[i],
                                      z.eval     = Z.xx[i],
                                      kernel     = kernel)[['y.hat']])*
    (Y.xk[i] -  KLL_mean_fun(YUZ.bigmat = YUZ.bigmat,
                             hu         = hu.mean.GCV,
                             hz         = hz.mean.GCV,
                             u.eval     = U.xk[i],
                             z.eval     = Z.xx[i],
                             kernel     = kernel)[['y.hat']])
  ## Feedback
  if( round((i/length(Y.jx))*100,digits=0) %% 10 == 0){
    if(print != round((i/length(Y.jx))*100,digits=0)){
      cat("Progress (Raw-Cov.Points)=",round((i/length(Y.jx))*100,digits=0),"%\n")
      print <- round((i/length(Y.jx))*100,digits=0)
    }
  }
}


## #############################################
## only noisy diagonal points:
C.ND.jk     <- C.jk[ND.pos]
U.ND.jx     <- U.jx[ND.pos]
U.ND.xk     <- U.xk[ND.pos]# equals 'U.ND.jx'
Z.ND.xx     <- Z.xx[ND.pos]
## only non-noisy off-diagonal terms:
C.jk        <- C.jk[!ND.pos]
U.jx        <- U.jx[!ND.pos]
U.xk        <- U.xk[!ND.pos]
Z.xx        <- Z.xx[!ND.pos]


CUUZ.bigmat <- cbind(C.jk, U.jx, U.xk, Z.xx)
CUUZ.bigmat <- as.big.matrix(CUUZ.bigmat)

## ##########################
## GCV-Bandwidth Selection 
## ##########################
GCV.grid.len     <- 5
GCV.cov.mat      <- matrix(NA,GCV.grid.len,GCV.grid.len)
hu.cov.seq       <- seq(0.3,1.0,len=GCV.grid.len)
hz.cov.seq       <- seq(0.3,1.0,len=GCV.grid.len)
##
cat("Now: GCV-cov\n")
for(i in 1:GCV.grid.len){
  for(j in 1:GCV.grid.len){
    GCV.cov.mat[i,j]  <- KLL_cov_fun(CUUZ.bigmat   = CUUZ.bigmat,
                              hu           = hu.cov.seq[i],
                              hz           = hz.cov.seq[j],
                              binning      = TRUE,
                              eval.at.data = TRUE,
                              bin.grid.len = 100,
                              kernel       = kernel)[['GCV']]
  }
}
GCV.cov.loc.min <- which(GCV.cov.mat == min(GCV.cov.mat), arr.ind = TRUE)
hu.cov.GCV      <- hu.cov.seq[GCV.cov.loc.min[1]] 
hz.cov.GCV      <- hz.cov.seq[GCV.cov.loc.min[2]]


## ###########################################################
## Estimating the covariance function ########################
## ###########################################################   


## estimation @ test-points
cov.TP.hat <- rep(NA, length(u.TP))
##
cat("Now: Estimating the covariance function\n")
for(i in 1:length(u.TP)){
  cov.TP.hat[i] <- KLL_cov_fun(CUUZ.bigmat = CUUZ.bigmat,
                             hu          = hu.cov.GCV,
                             hz          = hz.cov.GCV,
                             u.eval      = u.TP[i],
                             z.eval      = z.TP[i],
                             kernel      = kernel)[['c.hat']]
  ## Feedback
  cat("Progress (Cov @test-points)=",round((i/length(u.TP))*100,digits=0),"%\n")
}

## #########################################################################
## Estimating the noise-contaminated diagonal (gamma(u,u,z)+sigma^2_eps)
## #########################################################################
C.ND.UZ.bigmat     <- cbind(C.ND.jk, U.ND.jx, Z.ND.xx)
C.ND.UZ.bigmat     <- as.big.matrix(C.ND.UZ.bigmat)
## estimation @ test-points
cov.ND.TP.hat <- rep(NA,length(u.TP))
cat("Now: Estimating Noise-Contaminated diagonal\n")
for(i in 1:length(u.TP)){
  cov.ND.TP.hat[i] <- KLL_mean_fun(YUZ.bigmat = C.ND.UZ.bigmat,
                                  hu          = hu.cov.GCV,
                                  hz          = hz.cov.GCV,
                                  u.eval      = u.TP[i],
                                  z.eval      = z.TP[i],
                                  kernel      = kernel)[['y.hat']]
  ## Feedback
  cat("Progress (ND-Covariance)=",round((i/length(u.TP))*100,digits=0),"%\n")
}

## Density fits:
dens.Z.obj  <- density(Z.mat[1,], bw=bw.SJ(Z.mat[1,]), from=0, to=1)
dens.Z      <- splinefun(x=dens.Z.obj$x, y=dens.Z.obj$y) 
fZ.hat      <- dens.Z(z.TP)
##
dens.UZ.obj <- kde2d(x=U.vec, y=c(Z.mat), h=c(width.SJ(U.vec), width.SJ(Z.mat[1,])), lims=c(0, 1, 0, 1)) 
fUZ.hat     <- interp.surface(list("x"= dens.UZ.obj$x,
                                   "y"= dens.UZ.obj$y,
                                   "z"= dens.UZ.obj$z), loc = cbind(u.TP, z.TP))
## 

## Kernel constants
if(kernel=="Epanechnikov"){R_kappa <- (3/5);          nu2_kappa <- (1/5)}
if(kernel=="Gauss"){       R_kappa <- 1/(2*sqrt(pi)); nu2_kappa <- 1    }
## Mean
## Bias @test-points:
Bias.mean.TP  <- (1/2) * (nu2_kappa^2) * (hu.mean.GCV^2 * mean.DDu.TP.hat + hz.mean.GCV^2 * mean.DDz.TP.hat) 

## Variance-1 @test-points:
Var.1.mean.TP <- (n*m)^{-1} * hu.mean.GCV^{-1} * hz.mean.GCV^{-1} * R_kappa^2 * c(cov.ND.TP.hat/fUZ.hat)
Var.1.mean.TP[Var.1.mean.TP < 0] <- 0
## Variance-2 @test-points:
Var.2.mean.TP <- n^{-1} * ((m-1)/m) * hz.mean.GCV^{-1} * R_kappa * c(cov.TP.hat/fZ.hat)
Var.2.mean.TP[Var.2.mean.TP < 0] <- 0

## #############################################################
## Final results                                              ##
## #############################################################
## Bias-corrected mean-estim @test-points:                    ##
mean.hat.BC.TP <- mean.TP.hat - Bias.mean.TP                  ##
## (Sparse-to-Dense) Standard deviation @test-points:         ##
sd.hat.TP      <- sqrt(Var.1.mean.TP + Var.2.mean.TP)         ##
## #############################################################

