rm(list=ls())
#############################################
## VARIMAX Rotation of the Basisfunktions  ##
#############################################

###############################
load("TwoStepEstim.RData") ##
require(MSBVAR)              ##
require(pspline)             ##
require(locfit)              ##
###############################

## Discretize Eigenfunctions
B               <- predict(e.fun.hat, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE),length.out=n.ev.points))[,1:K]

## VARIMAX-Rotation
A               <- varimax(B)$loadings

## Interpolation of rotated eigenfunctions
e.fun.hat.rot   <- smooth.Pspline(x = seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE),length.out=n.ev.points),y = A)

## Compuation of new eigenvalues
e.v.rot <- numeric(K)
for(k in 1:K){
efun.rot.discr <- matrix(predict(e.fun.hat.rot,
                                 seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE),
                                     length.out=n.ev.points))[,k], ncol=1)
e.v.rot[k] <- t(efun.rot.discr) %*% W %*% G.hat.m %*% W %*% efun.rot.discr
}

## explained variance-shares
var.shares.rot <- e.v.rot/(sum(e.v[e.v>0]))
## comparision of orig. var-shares and rotated var-shares
e.v.rot/(sum(e.v[e.v>0]))
e.v[1:K]/(sum(e.v[e.v>0]))

## Rotated Var-shares
round(var.shares.rot,digits=4)*100

## rotation of scores 
T.rot      <- varimax(B)$rotmat
scores.rot <- t(t(scores[1:K,])%*%T.rot)

##############################################################
## Plot of the rotated eigenfunctions; Fig 3 (right panel): ##
##############################################################

scl     <- 1
scl.axs <- 1.4
scl.lab <- 1.4

scale1 <- mean(scores.rot[1,])
scale2 <- mean(scores.rot[2,])
par(mfrow=c(1,1))
plot(x=seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points),
     y=rep(0, length=n.ev.points),cex=scl,cex.lab=scl.lab, cex.axis=scl.axs,
     col="white", type="l",
     ylab="EUR/MWh", xlab="MW",
     ylim=c(-40,range(c(
       scale1*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,1],
       scale1*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,1],
       scale2*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,2],
       scale2*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,2])
       )[2])
     )
lines(x=seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points),
      y=scale1*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,1],
      lty=1)
lines(x=seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points),
      y=scale2*predict(e.fun.hat.rot, seq(min(U.mat, na.rm=TRUE), max(U.mat, na.rm=TRUE), length=n.ev.points))[,2],
      lty=2)
dev.off()

##########################################
## Plot of Scores; Fig 4                ##
##########################################
## The rotated eigenfunctions are determined up do sign-changes.
## Here: Convinient sign-choice such that both time series of
## Scores have positive trends

scl     <- 1
scl.axs <- 1
scl.lab <- 1

sgn1 <- ifelse(scores.rot[1,1]<scores.rot[1,T],1,-1)
sgn2 <- ifelse(scores.rot[2,1]<scores.rot[2,T],1,-1)

beta_1 <- scores.rot[1,]*sgn1
beta_2 <- scores.rot[2,]*sgn2

beta_1.plot <- NULL
beta_2.plot <- NULL
Da.mat.plot <- NULL
i <- 1

DUMMYFEIER.withoutSASU <- DUMMYFEIER[!c(as.logical(DUMMYSU)|as.logical(DUMMYSA))]
for(t in 1:length(DUMMYFEIER.withoutSASU)){
  if(DUMMYFEIER.withoutSASU[t]==0){
    beta_1.plot <- c(beta_1.plot, beta_1[i])
    beta_2.plot <- c(beta_2.plot, beta_2[i])
    Da.mat.plot <- c(Da.mat.plot, as.character(as.Date(Da.mat[1,i], format="%d.%m.%Y")))
    i <- i+1        
  }else{
    beta_1.plot <- c(beta_1.plot, NA)
    beta_2.plot <- c(beta_2.plot, NA)
    Da.mat.plot <- c(Da.mat.plot, NA)
  }
}
## months(as.Date(Da.mat.plot))

## Plot:
par(mar=c(5.1, 5.1, 4.1, 5.1),mfrow=c(1,1),cex.lab=1.2, cex.axis=1.2, cex=1.2)
plot.ts(beta_1.plot,lwd=1.125,main="",ylab="",
        xlab="Work days (January 1, 2006 - September 30, 2008)", ylim=c(-10000, 29000),axes=FALSE,frame=TRUE)
abline(v=(521), col="red", lwd=2)
axis(2, at=seq(2000, 28000,by=2000))
axis(1, cex.lab=1.0)
axis(3, at=(521), label="January 1, 2008", col.lab="red", padj = 1, cex.lab=scl.lab, col.ticks="red", lwd.ticks=2, tick=T)

par(new=TRUE)
plot.ts(beta_2.plot,main="",ylab="",
        xlab="",ylim=c(2718.894, 26583.584),axes=FALSE,frame=TRUE,lty=2,lwd=1.125)
axis(4,at=seq(2000,11000,by=2000))

legend("topleft",col=c("black","black"),lty=c(1,2),legend=c("1. Scores","2. Scores"),lwd=1.125)
par(mar=c(5.1, 4.1, 4.1, 2.1),mfrow=c(1,1))
dev.off()


tempr.data <- read.table("AUX_FUN_and_DATA/DATA/German_Tempr.txt",sep=",", header=TRUE)
loc <- match(c(as.Date(Da.mat[1,],format="%d.%m.%Y")),
             c(as.Date(as.character(tempr.data$Mess_Datum),format="%Y%m%d")))


## Granger tests:
pvalues <- c(
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=1)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=2)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=3)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=4)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=5)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=6)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=7)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=8)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=9)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=10)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=11)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=12)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=13)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=14)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=15)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=16)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=17)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=18)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=19)[1,2],
granger.test(ts(cbind(c(beta_1/beta_2),abs(tempr.data$LUFTTEMPERATUR[loc]-mean(tempr.data$LUFTTEMPERATUR[loc])))),p=20)[1,2])

###########################
## Plot of Figure 5      ##
###########################
plot(x=c(1:16),y=pvalues[1:16], ylab="p-values",xlab="Lag's",main="Granger-Causality Tests",type="o", ylim=c(0,0.05),
cex.lab=1.3, cex.axis=1.3, cex=1.3)
abline(h=0.05,lty=2); abline(h=0.01,lty=2)
par(cex.lab=1.0, cex.axis=1.0, cex=1.0)
dev.off()

##################################
save.image(file="VARIMAX.RData")##
##################################




