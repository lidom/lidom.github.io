################################################################################################################
## Data.Import.R:
## 1) Imports the Data from the csv-file: "Data_Jan_2006_Sep_2008.csv"
## 2) Re-orders the hourly spot prices according to the corresponding increasing values of electricity-demand
## Author: Dominik Liebl
## Date:   Mar.2013
#################################################################################################################
data.all <- read.csv(file="AUX_FUN_and_DATA/DATA/Data_Jan_2006_Sep_2008.csv", sep=";", header=TRUE)

## data-selector:=======================
peakload    <- rep(c(rep(FALSE,8),rep(TRUE,12),rep(FALSE,4)), (dim(data.all)[1]/24))
data.peakh  <- data.all[peakload,]
data.offph  <- data.all

## data.selector can be either data.selector="all", "peakh", or "offph"
data.list       <- switch(data.selector,
                          all   = list("data"=data.all,  "T"=dim(data.all)[1]/24,   "N"=24),
                          peakh = list("data"=data.peakh,"T"=dim(data.peakh)[1]/12, "N"=12),
                          offph = list("data"=data.offph,"T"=dim(data.offph)[1]/24, "N"=24))
##=======================================                     

## day-index variable
first.day   <- min(data.list$data$DayIndex)
last.day    <- max(data.list$data$DayIndex)
days        <- c(first.day:last.day)

## Selection of non-workdays:
source("AUX_FUN_and_DATA/holidays_and_brueckentage.R")
Sys.getlocale("LC_TIME")
Sys.setlocale("LC_TIME", "C")
Da.vec <- matrix(data.all$Date, nrow=24)[1,]
Da.vec <- as.Date(Da.vec, "%d.%m.%Y")
feier  <- as.Date(feiertage, "%d.%m.%Y")

DUMMYSU    <- as.numeric(weekdays(Da.vec)=="Sunday")
DUMMYSA    <- as.numeric(weekdays(Da.vec)=="Saturday")
DUMMYMO    <- as.numeric(weekdays(Da.vec)=="Monday")

DUMMYFEIER    <- as.numeric(!is.na(match(Da.vec,feier)))
DUMMYPSEUDOMO <- as.numeric(!is.na(match(Da.vec,feier+1)))

non.workdays  <- c(1:length((Da.vec)))[c(as.logical(DUMMYSU)|as.logical(DUMMYSA)|as.logical(DUMMYFEIER))]

## Taking non-workdays from the sample
tmp  <- match(non.workdays, days)
tmp  <- tmp[!is.na(tmp)]
days <- days[-tmp]

## Number of days 'T' and hours 'N':
T <- length(days)
N <- data.list$N

## Container for data
ord.mat       <- matrix(NA, N, T)
ord.RL        <- matrix(NA, N, T)
ord.RL.Prices <- matrix(NA, N, T)
ord.RL.Wind   <- matrix(NA, N, T)
ord.RL.Load   <- matrix(NA, N, T)
ord.RL.Lsmth  <- matrix(NA, N, T)
ord.RL.Dates  <- matrix(NA, N, T)

j <- 1
for(t in (days)){
  ord1                           <- order(data.list$data$ResLoad[data.list$data$DayIndex==t])
  ord.mat[,j]                    <- ord1
  ##
  ord.RL[,j]                     <- data.list$data$ResLoad[  data.list$data$DayIndex==t][ord1]
  ##
  ord.RL.Prices[,j]              <- data.list$data$Price[data.list$data$DayIndex==t][ord1]
  ##
  ord.RL.Wind[,j]                <- data.list$data$Windinfeed[data.list$data$DayIndex==t][ord1]
  ##
  ord.RL.Load[,j]                <- data.list$data$Load[      data.list$data$DayIndex==t][ord1]
  ##
  ord.RL.Dates[,j]               <- as.character(data.list$data$Date[data.list$data$DayIndex==t][ord1])
  j <- j+1
}
