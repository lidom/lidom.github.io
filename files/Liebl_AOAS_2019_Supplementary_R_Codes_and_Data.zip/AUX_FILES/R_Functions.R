## ##############################################
## SPR (Sparse Functional Data)
## ##############################################
bdw.mean.SPR.fun <- function(Q.mean.1, I.mean.uu, I.mean.zz, I.mean.uz, 
                             n=n, m=m, kernel){
  ## Kernel constants
  if(kernel=="Epanechnikov"){R_kappa <- (3/5);          nu2_kappa <- (1/5)}
  if(kernel=="Gauss"){       R_kappa <- 1/(2*sqrt(pi)); nu2_kappa <- 1    }
  ## U-direction
  hu.mean.SPR <- ( (R_kappa^2 * Q.mean.1 * I.mean.zz^(3/4)) /
                     (n * m * (nu2_kappa^2)^2 * (I.mean.uu^(1/2) * I.mean.zz^(1/2) + I.mean.uz) * I.mean.uu^(3/4)) )^(1/6)
  ## Z-direction
  hz.mean.SPR <- (I.mean.uu/I.mean.zz)^(1/4) * hu.mean.SPR
  ## Results
  return(list("hu.mean.SPR"=hu.mean.SPR, 
              "hz.mean.SPR"=hz.mean.SPR))
}
##########
bdw.cov.SPR.fun <- function(Q.cov.1, I.cov.u1u1, I.cov.u1u2, I.cov.zz, I.cov.u1z, 
                            n=n, M=M, kernel){
  ## Kernel constants
  if(kernel=="Epanechnikov"){R_kappa <- (3/5);          nu2_kappa <- (1/5)}
  if(kernel=="Gauss"){       R_kappa <- 1/(2*sqrt(pi)); nu2_kappa <- 1    }
  ##
  CI            <- (I.cov.u1z^2 + 4 * (I.cov.u1u1 + I.cov.u1u2) * I.cov.zz)^(1/2)
  ## U-direction
  hu.cov.SPR  <- ( (R_kappa^3 * Q.cov.1 * 4 * sqrt(2) * I.cov.zz^(3/2)) /
                     (n * M * (nu2_kappa^3)^2 * (2 * (nu2_kappa^3)^2 * I.cov.u1z + CI) *
                        (CI - I.cov.u1z)^(3/2)) )^(1/7)
  ## Z-direction
  hz.cov.SPR  <- ( (CI - I.cov.u1z) / (2 * I.cov.zz) )^(1/2) * hu.cov.SPR
  ## Results
  return(list("hu.cov.SPR"=hu.cov.SPR, 
              "hz.cov.SPR"=hz.cov.SPR))
}
##########
bdw.meanDD.SPR.fun <- function(Q.mean.1, I4.mean.uu, I4.mean.zz, I4.mean.uz, 
                             n=n, m=m, kernel){
  ## Kernel constants
  if(kernel=="Epanechnikov"){R_kappa <- (3/5);          nu2_kappa <- (1/5); CK <- 2.713}
  if(kernel=="Gauss"){       R_kappa <- 1/(2*sqrt(pi)); nu2_kappa <- 1    ; CK <- 1.298}
  ## U-direction
  hDDu.mean.SPR <- CK* ( (R_kappa^2 * Q.mean.1 * I4.mean.zz^(3/4)) /
                       (n * m * (nu2_kappa^2)^2 * (I4.mean.uu^(1/2) * I4.mean.zz^(1/2) + I4.mean.uz) * I4.mean.uu^(3/4)) )^(1/10)
  ## Z-direction
  hDDz.mean.SPR <- (I4.mean.uu/I4.mean.zz)^(1/4) * hDDu.mean.SPR
  ## Results
  return(list("hDDu.mean.SPR"=hDDu.mean.SPR, 
              "hDDz.mean.SPR"=hDDz.mean.SPR))
}


## ######################################
## Plotter function for 'mean.fun': 
## ######################################
my.mu.fun.plotter <- function(mu.fun, return.dat=FALSE){
  grid.len    <- 100 
  uu          <- seq(0,1,len=grid.len)
  zz          <- seq(0,1,len=grid.len)
  mu.values   <- matrix(mu.fun(u=rep(uu, times=grid.len),
                               z=rep(zz, each =grid.len)), grid.len, grid.len)
  image(x=uu, y=zz, z=mu.values, main="Meanfunction",
        xlab="Covariable U", ylab="Covariate Z", col = gray(seq(.25,.95,len=25)))
  if(return.dat){print(mu.values)}
}

## ######################################
## Plotter function for 'cov.fun': 
## ######################################
my.gamma.fun.plotter <- function(gamma.fun, set.par=TRUE){
  grid.len  <- 100 
  uu1       <- seq(0,1,len=grid.len)
  uu2       <- seq(0,1,len=grid.len)
  zz        <- seq(0,1,len=grid.len)
  if(set.par){par(mfrow=c(2,2))}
  for(i in 1:4){
    image(x=uu1, y=uu2,
          z=matrix(gamma.fun(u1=rep(uu1, times=grid.len),
                             u2=rep(uu2, each =grid.len),
                             z=quantile(zz, probs=seq(0.2,0.8,by=0.2))[i]),
                   grid.len, grid.len),
          xlab="Covariable U", ylab="Covariable U",
          main=paste0("Covariancefunction\n with covariate Z=",
                      c("0.2","0.4","0.6","0.8")[i]),
          col = gray(seq(.25,.95,len=15)))
  }
  if(set.par){par(mfrow=c(1,1))}
}


#################################
## Random Function Generator:  ##
#################################
X.fun <- function(u, z, lambda  = lambda.vec){
  score.1 <- rnorm(n=1, mean=0, sd=sqrt(lambda[1]))
  score.2 <- rnorm(n=1, mean=0, sd=sqrt(lambda[2]))   
  Fct     <- e.fun1(u,z) * score.1 +
    e.fun2(u,z) * score.2
  return(Fct)
}

## ##########################
## Error catching function
## ##########################

is.error <- function(x){
  bool.result <- inherits(x, "try-error")
  bool.result <- unname(bool.result)
  return(bool.result)
}


########################################################################
## Local Linear Estim-Function for a covariate adjusted mean function ##
########################################################################

KLL_mean_fun   <-  function(YUZ.bigmat 	 = YUZ.bigmat,
                            hu 			     = 0.15,
                           			hz 		       = 0.15,
                           			u.eval       = 0.5, 
                           			z.eval       = 0.5,
                           			eval.at.data = FALSE,
                                binning      = FALSE,
                                bin.grid.len = 50,
                           			kernel       = c("Gauss","Epanechnikov")[1],
                           			DD.est       = FALSE
                                ){
	## Checking arguments
	if(any(c(length(u.eval),length(z.eval))>1)){
		stop("Arguments 'u.eval' and 'z.eval' must have length 1.")
	}
  if(binning){
  	## ###############################################################
    ## Binning the data 
    ## The implementation is according to the binning-proposal of 
    ## MC Jones, 1997, Statistica Sinica, Vol. 7(4), pp. 1171--1180)
    ## ###############################################################
	  ## Binning grid-points and grid-widths
	  u.bg       <- seq(0,1,len=bin.grid.len); u.bw  <- u.bg[2] - u.bg[1]
    z.bg       <- seq(0,1,len=bin.grid.len); z.bw  <- z.bg[2] - z.bg[1]
    ## Orig. (U,Z)-points to grid-points
    UZ.all.b   <- t(apply(YUZ.bigmat[,c(2,3)],1,function(r){c(round(r/c(u.bw,z.bw))*c(u.bw,z.bw))}))
    ## Y-averages per grid-point
    Y.b        <- unlist(by(data.frame(YUZ.bigmat[,1],UZ.all.b), paste(UZ.all.b[,1],UZ.all.b[,2]), function(d){mean(d[,1])}))
    ## Keeping only unique grid points (corresponding to Y.b data)
    UZ.b       <- matrix(unlist(by(data.frame(UZ.all.b),         paste(UZ.all.b[,1],UZ.all.b[,2]), function(d){c(d[1,])})),ncol=2,byrow=TRUE)
    ## Final binning-Data
    YUZ.b      <- as.big.matrix(cbind(Y.b, UZ.b))
    ## ###############################################################
  }else{
    YUZ.b <- YUZ.bigmat
  }
  ##
  ## #####################################################
  ## Estimation of the original regression function
  ## #####################################################
	if(!DD.est){
    ## Container for results
    if(eval.at.data){
      result <- rep(NA,times=nrow(YUZ.b))
      S.mat  <- matrix(0,nrow(YUZ.b),nrow(YUZ.b))
    }else{
      result <- NA
      S.mat  <- matrix(0,1,nrow(YUZ.b))
    }
    ##
		for(k in 1:length(result)){
    		if(eval.at.data){
    			u.eval <- YUZ.b[k,2]; z.eval <- YUZ.b[k,3]
    		}
    		if(kernel=="Epanechnikov"){
       	 		## positions of local data
       	  		local.pos <- mwhich(YUZ.b, c(2,3), 
       	     		                list(c(u.eval-hu, u.eval+hu),
       	       	                     c(z.eval-hz, z.eval+hz)),
       	         		            list(c("ge","le"), c("ge","le")), "AND")
       	 		## computation of weights 
         		weights <- c((1-((YUZ.b[local.pos, 2]-u.eval)/hu)^2)*(3/4)*
               	         (1-((YUZ.b[local.pos, 3]-z.eval)/hz)^2)*(3/4))
          	weights[weights < 0] <- 0
         		## local LS fit
            Y  <- YUZ.b[,1,drop=FALSE][weights > 0]
            W  <- diag(weights[weights > 0])
            X  <- cbind(rep(1,nrow(YUZ.b)), YUZ.b[,2]-u.eval, YUZ.b[,3]-z.eval)[weights > 0,]
            ## Point (u.eval,z.eval)-specific entries of the smoothing matrix
            S.mat.tmp            <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[1,],silent = TRUE)
            if(is.error(S.mat.tmp)){
              warning("Too small bandwidth!")
              S.mat[k,weights > 0] <- NA
            }else{
              S.mat[k,weights > 0] <- S.mat.tmp
            }
            result[k] <- S.mat[k,weights > 0] %*% Y  
        	}
	        if(kernel=="Gauss"){
    	    	## computation of weights 
        		weights <- c(exp(-(((YUZ.b[, 2]-u.eval)/hu)^2)/2)/(2*sqrt(pi))*
           		           exp(-(((YUZ.b[, 3]-z.eval)/hz)^2)/2)/(2*sqrt(pi)))  
            ## effective zero weights
        		weights[weights < 1e-08] <- 0
        		## local LS fit
            Y  <- YUZ.b[,1,drop=FALSE][weights > 0]
            W  <- diag(weights[weights > 0])
            X  <- cbind(rep(1,nrow(YUZ.b)), YUZ.b[,2]-u.eval, YUZ.b[,3]-z.eval)[weights > 0,]
            ## Point (u.eval,z.eval)-specific entries of the smoothing matrix
            S.mat.tmp            <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[1,],silent = TRUE)
            if(is.error(S.mat.tmp)){
              warning("Too small bandwidth!")
              S.mat[k,weights > 0] <- NA
            }else{
              S.mat[k,weights > 0] <- S.mat.tmp
            }
            result[k]            <- S.mat[k,weights > 0] %*% Y  
      		}
    	}
      ##
    	if(eval.at.data){
        ##
        GCV <- mean(((result - YUZ.b[,1])/(1 - mean(diag(S.mat),na.rm=TRUE)))^2,na.rm=TRUE)
        ##
        if(binning){
          ## From bin grid points to actual data points 
    		  Ind    <- match(data.frame(t(UZ.all.b)), data.frame(t(UZ.b)))
    		  result <- result[Ind]	
          #S.mat  <- S.mat[Ind,Ind]
        }
    	}else{
        ## Smoothing matrix makes only sense if evaluation takes place at given data points 
        S.mat  <- NULL
      }
      if(eval.at.data){
   	    return(list("y.hat"=result,"GCV"=GCV))
      }else{
        return(list("y.hat"=result))
      }
  	}
    ## #####################################################
  	## Estimation of the second order partial derivatives
    ## #####################################################
  	if(DD.est){
    	## Container for results
      if(eval.at.data){
        resultDDu <- rep(NA,times=nrow(YUZ.b))
        resultDDz <- rep(NA,times=nrow(YUZ.b))
        S.matDDu  <- matrix(0,nrow(YUZ.b),nrow(YUZ.b))
        S.matDDz  <- matrix(0,nrow(YUZ.b),nrow(YUZ.b))
        y.DDu     <- rep(NA,length(resultDDu))
        y.DDz     <- rep(NA,length(resultDDu))
      }else{
        resultDDu <- NA
        resultDDz <- NA
        S.matDDu  <- matrix(0,1,nrow(YUZ.b))
        S.matDDz  <- matrix(0,1,nrow(YUZ.b))
      }
    	##
		  for(k in 1:length(resultDDu)){# k <- 9
    		if(eval.at.data){
    			u.eval <- YUZ.b[k,2]
          z.eval <- YUZ.b[k,3]
          ## 2nd central differences in U-direction
          DDyu.tmp <- unname(YUZ.b[z.eval == YUZ.b[,3], c(1,2), drop=FALSE])
          locu     <- which(DDyu.tmp[,2] == u.eval)
          if(locu>1 & locu < nrow(DDyu.tmp)){
            y.DDu[k]  <-  DDyu.tmp[locu+1,1] - 2* DDyu.tmp[locu,1] + DDyu.tmp[locu-1,1]          
          }
          ## 2nd central differences in Z-direction
          DDyz.tmp <- unname(YUZ.b[u.eval == YUZ.b[,2], c(1,3), drop=FALSE])
          locz     <- which(DDyz.tmp[,2] == z.eval)
          if(locz>1 & locz < nrow(DDyz.tmp)){
            y.DDz[k]  <-  DDyz.tmp[locz+1,1] - 2* DDyz.tmp[locz,1] + DDyz.tmp[locz-1,1]          
          }
    		}
        if(kernel=="Epanechnikov"){
        	## positions of local data
        	local.pos <- mwhich(YUZ.b, c(2,3), 
                              list(c(u.eval-hu, u.eval+hu),
                                   c(z.eval-hz, z.eval+hz)),
                              list(c("ge","le"), c("ge","le")), "AND")
          ## computation of weights 
          weights <- c((1-((YUZ.b[local.pos, 2]-u.eval)/(hu))^2)*(3/4)*
            	         (1-((YUZ.b[local.pos, 3]-z.eval)/(hz))^2)*(3/4))
          weights[weights < 0] <- 0
          ## local LS fit
          Y  <- YUZ.b[,1,drop=FALSE][weights > 0]
          W  <- diag(weights[weights > 0])
          u.cent <- c(YUZ.b[,2]-u.eval)[weights > 0]
          z.cent <- c(YUZ.b[,3]-z.eval)[weights > 0]
          X  <- cbind(rep(1,nrow(YUZ.b)),u.cent,u.cent^2,u.cent^3,z.cent,z.cent^2,z.cent^3)[weights > 0,]
          ## Point (u.eval,z.eval)-specific entries of the smoothing matrix
          ## Estimation of second derivatives
          S.matDDu.tmp <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[3,], silent = TRUE)
          if(is.error(S.matDDu.tmp)){
            warning("Too small bandwidth!")
            S.matDDu[k,weights > 0] <- NA
          }else{
            S.matDDu[k,weights > 0] <- S.matDDu.tmp
          } 
          resultDDu[k]            <- 2*S.matDDu[k,weights > 0] %*% Y 
          ##
          S.matDDz.tmp <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[6,], silent = TRUE)
          if(is.error(S.matDDz.tmp)){
            warning("Too small bandwidth!")
            S.matDDz[k,weights > 0] <- NA
          }else{
            S.matDDz[k,weights > 0] <- S.matDDz.tmp
          } 
          resultDDz[k]            <- 2*S.matDDz[k,weights > 0] %*% Y  
        }
	     if(kernel=="Gauss"){
    	    ## computation of weights 
          weights <- c(exp(-(((YUZ.b[, 2]-u.eval)/(hu))^2)/2)/(2*sqrt(pi))*
             	         exp(-(((YUZ.b[, 3]-z.eval)/(hz))^2)/2)/(2*sqrt(pi)))  
          ## effective zero weights
          weights[weights < 0] <- 0
          ## local LS fit
          Y  <- YUZ.b[,1,drop=FALSE][weights > 0]
          W  <- diag(weights[weights > 0])
          u.cent <- c(YUZ.b[,2]-u.eval)[weights > 0]
          z.cent <- c(YUZ.b[,3]-z.eval)[weights > 0]
          X  <- cbind(rep(1,nrow(YUZ.b)),u.cent,u.cent^2,u.cent^3,z.cent,z.cent^2,z.cent^3)[weights > 0,]
          ## Point (u.eval,z.eval)-specific entries of the smoothing matrix
          ## Estimation of second derivatives
          S.matDDu.tmp <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[3,], silent = TRUE)
          if(is.error(S.matDDu.tmp)){
            warning("Too small bandwidth!")
            S.matDDu[k,weights > 0] <- NA
          }else{
            S.matDDu[k,weights > 0] <- S.matDDu.tmp
          } 
          resultDDu[k]            <- 2*S.matDDu[k,weights > 0] %*% Y 
          ##
          S.matDDz.tmp <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[6,], silent = TRUE)
          if(is.error(S.matDDz.tmp)){
            warning("Too small bandwidth!")
            S.matDDz[k,weights > 0] <- NA
          }else{
            S.matDDz[k,weights > 0] <- S.matDDz.tmp
          } 
          resultDDz[k]            <- 2*S.matDDz[k,weights > 0] %*% Y  
        }
      }
      if(eval.at.data){
        GCV.DDu <- mean(((resultDDu - y.DDu)/(1 - mean(diag(S.matDDu), na.rm=TRUE)))^2, na.rm=TRUE)
        GCV.DDz <- mean(((resultDDz - y.DDz)/(1 - mean(diag(S.matDDz), na.rm=TRUE)))^2, na.rm=TRUE)
        if(binning){
    		  Ind       <- match(data.frame(t(UZ.all.b)), data.frame(t(UZ.b)))
    		  resultDDu <- resultDDu[Ind]
          #S.matDDu  <- S.matDDu[Ind,Ind]
    		  resultDDz <- resultDDz[Ind]	
          #S.matDDz  <- S.matDDz[Ind,Ind]
        }
    	}else{
        ## Smoothing matrix makes only sense if evaluation takes place at given data points 
        S.matDDu  <- NULL
        S.matDDz  <- NULL
      }
      if(eval.at.data){
    	 return(list(
         "y.hat.DDu"=resultDDu,
         "y.hat.DDz"=resultDDz,
         "GCV.DDu"  =GCV.DDu,
         "GCV.DDz"  =GCV.DDz))
      }else{
        return(list(
         "y.hat.DDu"=resultDDu,
         "y.hat.DDz"=resultDDz))
      }
	}
}


temper.f <- function (b, tmp=c(0.1,0.2)) {
  b[b < tmp[1]] <- tmp[1]
  b[b > tmp[2]] <- tmp[2]
  b
}

##############################################################################
## Local Linear Estim-Function for a covariate adjusted covariance function ##
##############################################################################

KLL_cov_fun   <- function(CUUZ.bigmat = CUUZ.bigmat,
                          hu          = 0.15,
                          hz          = 0.15,
                          u.eval      = 0.5,
                          z.eval      = 0.5,
                          eval.at.data = FALSE,
                          binning      = FALSE,
                          bin.grid.len = 50,
                          kernel       = c("Gauss","Epanechnikov")[1]){
  ## Checking arguments
  if(any(c(length(u.eval),length(z.eval))>1)){
    stop("Arguments 'u.eval' and 'z.eval' must have length 1.")
  }
  if(binning){
    ## ###############################################################
    ## Binning the data 
    ## The implementation is according to the binning-proposal of 
    ## MC Jones, 1997, Statistica Sinica, Vol. 7(4), pp. 1171--1180)
    ## ###############################################################
    ## Binning grid-points and grid-widths
    u1.bg      <- seq(0,1,len=bin.grid.len); u1.bw  <- u1.bg[2] - u1.bg[1]
    u2.bg      <- u1.bg;                     u2.bw  <- u1.bw
    z.bg       <- seq(0,1,len=bin.grid.len); z.bw   <- z.bg[2]  - z.bg[1]
    ## Orig. (U,U,Z)-points to grid-points
    UUZ.all.b  <- t(apply(CUUZ.bigmat[,c(2:4)],1,function(r){c(round(r/c(u1.bw,u2.bw,z.bw))*c(u1.bw,u2.bw,z.bw))}))
    ## C-averages per grid-point
    C.b        <- unlist(by(data.frame(CUUZ.bigmat[,1],UUZ.all.b), paste(UUZ.all.b[,1],UUZ.all.b[,2]),function(d){mean(d[,1])}))
    ## Keeping only unique grid points (corresponding to Y.b data)
    UUZ.b      <- matrix(unlist(by(data.frame(UUZ.all.b),          paste(UUZ.all.b[,1],UUZ.all.b[,2]),function(d){c(d[1,])})),ncol=3,byrow=TRUE)
    ## Final binning-Data
    CUUZ.b     <- as.big.matrix(cbind(C.b,UUZ.b))
    ## ###############################################################
  }else{
    CUUZ.b <- CUUZ.bigmat
  }
  ##
  ## #####################################################
  ## Estimation of the original regression function
  ## #####################################################
  ## Container for results
  if(eval.at.data){
    result <- rep(NA,times=nrow(CUUZ.b))
    S.mat  <- matrix(0,nrow(CUUZ.b),nrow(CUUZ.b))
  }else{
    result <- NA
    S.mat  <- matrix(0,1,nrow(CUUZ.b))
  }
  ##
  for(k in 1:length(result)){
    if(eval.at.data){
      u.eval <- CUUZ.b[k,2]; z.eval <- CUUZ.b[k,3]
    }
    if(kernel=="Epanechnikov"){
      ## positions of local data
      local.pos <- mwhich(CUUZ.b, c(2,3,4), list(c(u.eval-hu, u.eval+hu),
                                                 c(u.eval-hu, u.eval+hu),
                                                 c(z.eval-hz, z.eval+hz)),
                          list(c("ge","le"), c("ge","le"), c("ge","le")), "AND")
      ## computation of weights
      weights <- c((1-((CUUZ.b[local.pos, 2]-u.eval)/hu)^2)*(3/4)*
                   (1-((CUUZ.b[local.pos, 3]-u.eval)/hu)^2)*(3/4)*
                   (1-((CUUZ.b[local.pos, 4]-z.eval)/hz)^2)*(3/4))
      weights[weights < 0] <- 0
      ## local LS fit
      Y  <- CUUZ.b[,1,drop=FALSE][weights > 0]
      W  <- diag(weights[weights > 0])
      X  <- cbind(rep(1,nrow(CUUZ.b)), CUUZ.b[,2]-u.eval, CUUZ.b[,3]-u.eval, CUUZ.b[,4]-z.eval)[weights > 0,]
      ## Point (u.eval,u.eval,z.eval)-specific entries of the smoothing matrix
      S.mat.tmp            <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[1,],silent = TRUE)
      if(is.error(S.mat.tmp)){
        warning("Too small bandwidth!")
        S.mat[k,weights > 0] <- NA
      }else{
        S.mat[k,weights > 0] <- S.mat.tmp
      }
      result[k]            <- S.mat[k,weights > 0] %*% Y  
    }
    if(kernel=="Gauss"){
      ## computation of weights 
      weights <- c(exp(-(((CUUZ.b[, 2]-u.eval)/hu)^2)/2)/(2*sqrt(pi))*
                   exp(-(((CUUZ.b[, 3]-u.eval)/hu)^2)/2)/(2*sqrt(pi))*   
                   exp(-(((CUUZ.b[, 4]-z.eval)/hz)^2)/2)/(2*sqrt(pi)))  
      weights[weights < 0] <- 0
      ## local LS fit
      Y  <- CUUZ.b[,1,drop=FALSE][weights > 0]
      W  <- diag(weights[weights > 0])
      X  <- cbind(rep(1,nrow(CUUZ.b)), CUUZ.b[,2]-u.eval, CUUZ.b[,3]-u.eval, CUUZ.b[,4]-z.eval)[weights > 0,]
      ## Point (u.eval,u.eval,z.eval)-specific entries of the smoothing matrix
      S.mat.tmp            <- try((solve(t(X) %*% W %*% X) %*% t(X) %*% W)[1,],silent = TRUE)
      if(is.error(S.mat.tmp)){
        warning("Too small bandwidth!")
        S.mat[k,weights > 0] <- NA
      }else{
        S.mat[k,weights > 0] <- S.mat.tmp
      }
      result[k]      <- S.mat[k,weights > 0] %*% Y  
    }
  }
  ##
  if(eval.at.data){
    ##
    GCV <- mean(((result - as.vector(C.b))/(1 - mean(diag(S.mat))))^2)
    ##
    if(binning){
      ## From bin grid points to actual data points 
      Ind    <- match(data.frame(t(UUZ.all.b)), data.frame(t(UUZ.b)))
      result <- result[Ind] 
    }
  }else{
    ## Smoothing matrix makes only sense if evaluation takes place at given data points 
    S.mat  <- NULL
  }
  if(eval.at.data){
    return(list("c.hat"=result,"GCV"=GCV))
  }else{
    return(list("c.hat"=result))
  }
}

