############################################
## Estimation: Std of additive Errorterm: ##
############################################

tmp <- NULL
for(t in 1:T){
  tmp <- c(tmp,as.vector(predict(X.smGCVSmth[[t]], U.mat.orig.without.Otl[,t][!is.na(U.mat.orig.without.Otl[,t])])))
}

Y.vec.orig.without.Otl <- c(Y.mat.orig.without.Otl)
tmp <- (Y.vec.orig.without.Otl[!is.na(Y.vec.orig.without.Otl)]-tmp)^2

sig2.hat <- mean(tmp[tmp<quantile(tmp,p=0.95)])

Y.vec.RES.AIC      <- as.vector(Y.mat.orig)
U.vec.RES.AIC      <- as.vector(U.mat.orig)

U.vec.RES.AIC[Y.vec.RES.AIC > price.Otl] <- NA
Y.vec.RES.AIC[Y.vec.RES.AIC > price.Otl] <- NA

Y.mat.RES.AIC      <- matrix(Y.vec.RES.AIC,  24,T)
U.mat.RES.AIC      <- matrix(U.vec.RES.AIC, 24,T)

################
K.tmp          <- 3
################

scores.3     <- matrix(NA,K.tmp,T)
for(t in 1:T){
  tmp.lm     <- summary(lm(as.vector(X.tilde.mat[,t][!is.na(X.tilde.mat[,t])])~0 +
                         as.vector(phi.i.hat[[t]][,1])+
                         as.vector(phi.i.hat[[t]][,2])+
                         as.vector(phi.i.hat[[t]][,3])
                         ))
scores.3[,t] <- tmp.lm$coefficients[,1]
}


RES.mat.3         <- matrix(NA, 24, T)

for(t in 1:T){
  RES.mat.3[,t][!is.na(U.mat.RES.AIC[,t])] <- c(Y.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])-
        c(0+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,1])*scores.3[1,t]*c_t[t]+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,2])*scores.3[2,t]*c_t[t]+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,3])*scores.3[3,t]*c_t[t]
       )
}

AIC.K3.RSS <- apply(X=RES.mat.3, MARGIN=2,FUN=sum, na.rm=T)


N_t.log.2pi_2         <- rep(N,T)*log(2*pi)/2
N_t.log.sig2.hat_2    <- rep(N,T)*log(sig2.hat)/2

AIC.K3.RSS_2.sig2.hat <- AIC.K3.RSS/(2*sig2.hat)

L3 <- sum(c(-N_t.log.2pi_2 -N_t.log.sig2.hat_2 -AIC.K3.RSS_2.sig2.hat))


################
K.tmp          <- 2
################
scores.2     <- matrix(NA,K.tmp,T)
for(t in 1:T){
  tmp.lm     <- summary(lm(as.vector(X.tilde.mat[,t][!is.na(X.tilde.mat[,t])])~0 +
                         as.vector(phi.i.hat[[t]][,1])+
                         as.vector(phi.i.hat[[t]][,2])
                         ))
scores.2[,t] <- tmp.lm$coefficients[,1]
}

RES.mat.2         <- matrix(NA, 24, T)

for(t in 1:T){
  RES.mat.2[,t][!is.na(U.mat.RES.AIC[,t])] <- c(Y.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])-
        c(0+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,1])*scores.2[1,t]*c_t[t]+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,2])*scores.2[2,t]*c_t[t]
       )
}

AIC.K2.RSS <- apply(X=RES.mat.2, MARGIN=2,FUN=sum, na.rm=T)


N_t.log.2pi_2         <- rep(N,T)*log(2*pi)/2
N_t.log.sig2.hat_2    <- rep(N,T)*log(sig2.hat)/2

AIC.K2.RSS_2.sig2.hat <- AIC.K2.RSS/(2*sig2.hat)

L2 <- sum(c(-N_t.log.2pi_2 -N_t.log.sig2.hat_2 -AIC.K2.RSS_2.sig2.hat))

################
K.tmp          <- 1
################
scores.1     <- matrix(NA,K.tmp,T)
for(t in 1:T){
  tmp.lm     <- summary(lm(as.vector(X.tilde.mat[,t][!is.na(X.tilde.mat[,t])])~0 +
                         as.vector(phi.i.hat[[t]][,1])
                         ))
scores.1[,t] <- tmp.lm$coefficients[,1]
}

RES.mat.1         <- matrix(NA, 24, T)

for(t in 1:T){
  RES.mat.1[,t][!is.na(U.mat.RES.AIC[,t])] <- c(Y.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])-
        c(0+
         (predict(e.fun.hat, U.mat.RES.AIC[,t][complete.cases(U.mat.RES.AIC[,t])])[,1])*scores.1[1,t]*c_t[t]
       )
}

AIC.K1.RSS <- apply(X=RES.mat.1, MARGIN=2,FUN=sum, na.rm=T)


N_t.log.2pi_2         <- rep(N,T)*log(2*pi)/2
N_t.log.sig2.hat_2    <- rep(N,T)*log(sig2.hat)/2

AIC.K1.RSS_2.sig2.hat <- AIC.K1.RSS/(2*sig2.hat)

L1 <- sum(c(-N_t.log.2pi_2 -N_t.log.sig2.hat_2 -AIC.K1.RSS_2.sig2.hat))
