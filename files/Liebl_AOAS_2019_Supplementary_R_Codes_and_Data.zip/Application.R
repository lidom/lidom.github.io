## ##################
## Set your paths: ##
## ##################

## Location to save the plots
plot_path     <- "your_plot_directory"
## Set your working directory to the directory 'R_Codes_and_Data'
personal_path <- "your_path_to/R_Codes_and_Data"
setwd(personal_path)


## ##############
## Libraries   ##
## ##############

## The following R-packages need to be installed and loaded.

## The used versions of the packages are provided 
## locally in order to facilitate reproducability
install.packages("AUX_FILES/R_packages/pspline_1.0-18.tar.gz",     repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/RColorBrewer_1.1-2.tar.gz", repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/scales_1.0.0.tar.gz",       repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/bigmemory_4.5.33.tar.gz",   repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/zoo_1.8-4.tar.gz",          repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/MASS_7.3-51.1.tar.gz",      repos = NULL, type="source")
install.packages("AUX_FILES/R_packages/fields_9.6.tar.gz",         repos = NULL, type="source")
## Alternatively, use install.packages() to install them from CRAN.

## Load R-packages
library("pspline")      # Used for estimating the boundaries [a(z),b(z)]
library("RColorBrewer") # Nice color scales
library("scales")       # alpha() for transparent colors
library("bigmemory")    # Large matrices
library("zoo")          # Handling of dates
library("MASS")         # kde2d() bivariate densitiy estimation 
library("fields")       # interp.surface() bivariate interpolations

## ##########################################################
## Loading own R functions: 
## ##########################################################
## This loads:
## -Local linear kernel estimators
## -Bandwidth functions
## -Functions to plot the mean and covariance functions 
source("AUX_FILES/R_Functions.R")

## Integral approximation:
NrMaxEval <- 50
## Choose kernel function:
kernel    <- "Gauss"


## #############
## Read data  ##
## #############
## Electricity data 
data.electr   <- read.csv(file="DATA/DATA_electricity.csv", header=TRUE)
head(data.electr)
## Air temperature data
data.airtemp  <- read.csv(file="DATA/DATA_airtemp.csv", header=TRUE)
head(data.airtemp)
## Holidays:
data.holidays <- read.csv(file="DATA/DATA_holidays.csv", sep=";", header=TRUE)$Holidays
holidays      <- as.Date(as.character(data.holidays), "%d.%m.%Y")
head(holidays)
## Data of Figure 6 in Grossi et al. (2017)
## Extracted using the WebPlotDigitizer (https://automeris.io/WebPlotDigitizer/)
Grossi_Fig6_df <- read.csv(file = "DATA/Grossi_et_al_2017_Fig_6.csv")
head(Grossi_Fig6_df)

## Sample sizes
m <- 24                  # 24 hours (will be reduced to the 12 peak hours)
n <- nrow(data.electr)/m # number of days 

## Date-vector and -matrix 
Da.vec <- as.Date(as.character(data.electr$Date), "%d.%m.%Y")
Da.mat <- matrix(as.character(Da.vec),nrow=m,ncol=n)


## ###########################################################
## Selection of working days within the relevant time period
## ###########################################################
days          <- unique(Da.vec)
days.Mo_Fr    <- days[!c(weekdays(as.Date(days))=="Sonntag" | weekdays(as.Date(days))=="Samstag")]
holidays.loc  <- c(na.omit(charmatch(holidays, days.Mo_Fr)))
work.days     <- days.Mo_Fr[-holidays.loc]
## One year before and one year after the atom moratorium
work.days     <- work.days[work.days > as.Date("2010-03-14") & work.days <= as.Date("2012-03-14")]
## update total number of days
n             <- length(work.days)
## peak hours and update number of hours
slct.h        <- c(9:20)
m             <- length(slct.h)


## #####################################
## Y- and U-data  (Prices and Demand)
## #####################################
ord.mat          <- matrix(NA, m, n) # allows to reorder the data 
Da.mat           <- matrix(NA, m, n)
U.mat            <- matrix(NA, m, n)
Y.mat            <- matrix(NA, m, n)
# Residual electricity demand:
Res.Demand       <- data.electr$Demand-
                    data.electr$PV-
                    data.electr$Wind +
                    data.electr$Netimport 
for(i in 1:length(work.days)){
  ord.tmp       <- order(Res.Demand[ Da.vec==work.days[i]][slct.h])
  ord.mat[,i]   <- ord.tmp
  U.mat[,i]     <- Res.Demand[       Da.vec==work.days[i]][slct.h][ord.tmp]
  Y.mat[,i]     <- data.electr$Price[Da.vec==work.days[i]][slct.h][ord.tmp]
  Da.mat[,i]    <- rep(as.character(work.days[i]),m)
}
rm(ord.tmp)

## ######################################
## Selection of relevant time periods (before and after atom moratorium)
## ######################################
Da.vec       <- Da.mat[1,]
## Before moratorium
selct.BM     <- Da.vec > as.Date("2010-03-14") & Da.vec <= as.Date("2011-03-14")
Y.mat.BM     <- Y.mat[ ,selct.BM]
U.mat.BM     <- U.mat[ ,selct.BM]
Da.mat.BM    <- Da.mat[,selct.BM]
Da.vec.BM    <- Da.vec[ selct.BM]
(n.BM        <- ncol(Y.mat.BM))
## After moratorium
selct.AM     <- Da.vec > as.Date("2011-03-14") & Da.vec <= as.Date("2012-03-14")
Y.mat.AM     <- Y.mat[ ,selct.AM]
U.mat.AM     <- U.mat[ ,selct.AM]
Da.mat.AM    <- Da.mat[,selct.AM]
Da.vec.AM    <- Da.vec[ selct.AM]
(n.AM        <- ncol(Y.mat.AM))   

## ############################
## Z-covariate (temperature)
## ############################
tempr.df.BM <- data.frame(date=as.Date(as.character(data.airtemp[,1]),format="%Y%m%d"), tempr=data.airtemp[,2])
Z.tmp.BM    <- tempr.df.BM[charmatch(Da.vec.BM, tempr.df.BM$date),]$tempr
Z.mat.BM    <- matrix(rep(Z.tmp.BM, each=m), nrow=m, ncol=n.BM)
rm(Z.tmp.BM)
##
tempr.df.AM <- data.frame(date=as.Date(as.character(data.airtemp[,1]),format="%Y%m%d"), tempr=data.airtemp[,2])
Z.tmp.AM    <- tempr.df.AM[charmatch(Da.vec.AM, tempr.df.AM$date),]$tempr
Z.mat.AM    <- matrix(rep(Z.tmp.AM, each=m), nrow=m, ncol=n.AM)
rm(Z.tmp.AM)
##
Y.vec.BM    <- c(Y.mat.BM)
U.vec.BM    <- c(U.mat.BM)
Z.vec.BM    <- c(Z.mat.BM)
any(is.na(c(Y.vec.BM,U.vec.BM,Z.vec.BM)))
##
Y.vec.AM    <- c(Y.mat.AM)
U.vec.AM    <- c(U.mat.AM)
Z.vec.AM    <- c(Z.mat.AM)
any(is.na(c(Y.vec.AM,U.vec.AM,Z.vec.AM)))

## Outliers Handling: ##############
price.otl.high      <- 200        ##
## #################################

## 	How many outliers?
(length(Y.vec.BM[Y.vec.BM > price.otl.high])+length(Y.vec.AM[Y.vec.AM > price.otl.high]))/
  (length(Y.vec.BM)+length(Y.vec.AM)) * 100

Y.vec.BM[Y.vec.BM > price.otl.high] <- price.otl.high
Y.vec.AM[Y.vec.AM > price.otl.high] <- price.otl.high

Y.mat.BM <- matrix(Y.vec.BM, m, n.BM)
Y.mat.AM <- matrix(Y.vec.AM, m, n.AM)  

## #####################################
## Data in original hourly ordering:
## #####################################
Y.mat.reord <- matrix(NA,m,n)
U.mat.reord <- matrix(NA,m,n)
for(i in 1:n){
    Y.mat.reord[,i] <- Y.mat[,i][order(ord.mat[,i])]
    U.mat.reord[,i] <- U.mat[,i][order(ord.mat[,i])]
}
##
Y.mat.reord.BM <- Y.mat.reord[,selct.BM]
Y.mat.reord.AM <- Y.mat.reord[,selct.AM]
U.mat.reord.BM <- U.mat.reord[,selct.BM]
U.mat.reord.AM <- U.mat.reord[,selct.AM]
##
Y.reord.BM.vec <- c(Y.mat.reord.BM)
Y.reord.AM.vec <- c(Y.mat.reord.AM)
U.reord.BM.vec <- c(U.mat.reord.BM)
U.reord.AM.vec <- c(U.mat.reord.AM)

## ################################
## Data for the Benchmark Analyses
## ################################

## Price data (CO2-certificates, gas, and coal)
DATA_benchmark <- read.csv("DATA/DATA_benchmark_studies.csv")
head(DATA_benchmark)
# Price-Units: 
# Coal: USD/t
# co2:  EUR/EUA, where one EUA (European Union Allowance) allows for the emission of one ton CO2
# gas:  EUR/MWh

## ########################################
## Event Study (ES)
## ########################################
start_date <- c("2011-02-08") # -24 working days
end_date   <- c("2011-04-14") # +24 working days
##
ES_Time_Frame <- as.POSIXct(DATA_benchmark$time) >= as.POSIXct(as.Date(start_date)) & 
                 as.POSIXct(DATA_benchmark$time) <= as.POSIXct(as.Date(end_date)) 

length(ES_Time_Frame[ES_Time_Frame==TRUE])
##
price_electr_PHmean_ES <- DATA_benchmark$price_electr_PHmean[ES_Time_Frame]
dummy_AM_ES            <- c(rep(0, 24), rep(1, 24)) 
res_demand_PHmean_ES   <- DATA_benchmark$res_demand_PHmean[ES_Time_Frame]
temperature_ES         <- DATA_benchmark$temperature[ES_Time_Frame]
price_co2_ES           <- DATA_benchmark$price_co2[ES_Time_Frame]
price_coal_ES          <- DATA_benchmark$price_coal[ES_Time_Frame]
price_gas_ES           <- DATA_benchmark$price_gas[ES_Time_Frame]
##
summary(as.factor(dummy_AM_ES))
(n_days_TF1           <- length(price_electr_PHmean_ES))

## ###################
## Benchmark Models 1
## ###################

## Benchmark Model 1.1 
fit_BM_1_1 <- lm(price_electr_PHmean_ES ~ dummy_AM_ES)
summary(fit_BM_1_1)

## Benchmark Model 1.2 
fit_BM_1_2 <- lm(price_electr_PHmean_ES ~ 
                   dummy_AM_ES    +
                   price_co2_ES   +
                   price_coal_ES  + 
                   price_gas_ES)
summary(fit_BM_1_2)

## Benchmark Model 1.3
fit_BM_1_3 <- lm(price_electr_PHmean_ES ~ 
                   dummy_AM_ES         +
                   temperature_ES      + 
                   I(temperature_ES^2) + 
                   price_co2_ES        +
                   price_coal_ES       + 
                   price_gas_ES)
summary(fit_BM_1_3)

## Benchmark Model 1.4
fit_BM_1_4 <- lm(price_electr_PHmean_ES ~ 
                   dummy_AM_ES         +
                   temperature_ES      + 
                   I(temperature_ES^2))
summary(fit_BM_1_4)

## ###################
## Benchmark Model 2 
## ###################

## Benchmark Model 2.1
fit_BM_2_1 <- lm(price_electr_PHmean_ES ~
                   dummy_AM_ES +
                   ##
                   res_demand_PHmean_ES      +
                   I(res_demand_PHmean_ES^2) +
                   ##
                   I(res_demand_PHmean_ES   * dummy_AM_ES) +
                   I(res_demand_PHmean_ES^2 * dummy_AM_ES))
summary(fit_BM_2_1)

## Benchmark Model 2.2
fit_BM_2_2 <- lm(price_electr_PHmean_ES ~
                   dummy_AM_ES +
                   ##
                   res_demand_PHmean_ES      +
                   I(res_demand_PHmean_ES^2) +
                   ##
                   I(res_demand_PHmean_ES   * dummy_AM_ES) +
                   I(res_demand_PHmean_ES^2 * dummy_AM_ES) +
                   ##
                   price_co2_ES   +
                   price_coal_ES  + 
                   price_gas_ES)
summary(fit_BM_2_2)

## Benchmark Model 2.3
fit_BM_2_3 <- lm(price_electr_PHmean_ES ~ 
                   dummy_AM_ES +
                   ##
                   res_demand_PHmean_ES      + 
                   I(res_demand_PHmean_ES^2) +
                   ##
                   I(res_demand_PHmean_ES   * dummy_AM_ES) + 
                   I(res_demand_PHmean_ES^2 * dummy_AM_ES) +
                   ##
                   temperature_ES + 
                   I(temperature_ES^2) +   
                   price_co2_ES   +
                   price_coal_ES  + 
                   price_gas_ES)
summary(fit_BM_2_3)

## Benchmark Model 2.4
fit_BM_2_4 <- lm(price_electr_PHmean_ES ~ 
                   dummy_AM_ES +
                   ##
                   res_demand_PHmean_ES      + 
                   I(res_demand_PHmean_ES^2) +
                   ##
                   I(res_demand_PHmean_ES   * dummy_AM_ES) + 
                   I(res_demand_PHmean_ES^2 * dummy_AM_ES) +
                   ##
                   temperature_ES + 
                   I(temperature_ES^2))
summary(fit_BM_2_4)

## Model comparisions
## I vs II
anova(fit_BM_1_1, fit_BM_1_2)
anova(fit_BM_2_1, fit_BM_2_2)
## II vs III
anova(fit_BM_1_2, fit_BM_1_3)
anova(fit_BM_2_2, fit_BM_2_3)
## III vs IV
anova(fit_BM_1_3, fit_BM_1_4)
anova(fit_BM_2_3, fit_BM_2_4)


## ####################
## Color-Scheme      ##
## ####################
base.cols            <- rev(brewer.pal(11, "RdYlBu"))
Z.steps              <- max(round((na.omit(c(Z.vec.BM, Z.vec.AM)) - min(c(Z.vec.BM, Z.vec.AM), na.rm=TRUE)), digits=0)/10)
## Allocation of Z.vec values to one of the 11 temperature colors
col.pos.BM           <- c(round((Z.vec.BM - min(c(Z.vec.BM, Z.vec.AM), na.rm=TRUE))/Z.steps, digits=0)+1)
col.pos.AM           <- c(round((Z.vec.AM - min(c(Z.vec.BM, Z.vec.AM), na.rm=TRUE))/Z.steps, digits=0)+1)
rm(Z.steps)
## Define Color-Vector/Matrix
clrs.vec.BM            <- base.cols[col.pos.BM]
clrs.mat.BM            <- matrix(clrs.vec.BM,m,n.BM)
clrs.vec.AM            <- base.cols[col.pos.AM]
clrs.mat.AM            <- matrix(clrs.vec.AM,m,n.AM)


## ###################################################
## Figure 2: Scatter-plot of the raw data 
## ###################################################
## pdf(paste0(plot_path, "Fig_2.pdf"), width=8, height=4.5)
shift <- 250
par(mfrow=c(1,1), font.main=1, family="serif", mar=c(4,4,1,1)+0.1, ps=13)
matplot(x=cbind(U.mat.BM, U.mat.AM), y=cbind(Y.mat.BM, Y.mat.AM - shift),
        xlab="Electricity Demand (MW)",ylab="Electricity Prices (EUR/MWh)", main="",
        type="n", ylim=c(-215, 145), xlim=c(15000,98000),
        axes=FALSE,frame=FALSE)
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = gray(.85), border=gray(.85))
axis(1, at = c(20000,40000,60000,80000))
axis(2, at = c(50, 100, 150, 200) - shift, labels = c(50, 100, 150, 200))
axis(2, at = c(50, 100, 150),              labels = c(50, 100, 150))
##
for(t in 1:n.BM){
  points(x=U.mat.BM[,t], y=Y.mat.BM[,t], pch=21, cex=1, lwd=1,
         bg=matrix(clrs.vec.BM,m)[1,t], col=matrix(clrs.vec.BM,m)[1,t])
}
text(x=12500, y=125,         labels="Before Germany's nuclear phaseout", pos = 4)
lines(x = c(par("usr")[1]+5000, par("usr")[2]-5000), y = c(-10, -10), lwd = 1, col = gray(0))
text(x=12500, y=200 - shift, labels="After Germany's nuclear phaseout",  pos = 4)
####
t.slct1 <- 23; Da.mat.BM[1,t.slct1]
##
points(x=U.mat.BM[,t.slct1], y=Y.mat.BM[,t.slct1], pch=21, cex=1, bg="black",col="black",lwd=1)
legend(x=12500, y=120, c("m=12 Data Points of Apr. 16, 2010"), pch=c(21), pt.bg="black", cex=.95, col="black", bty = "n")
## 
for(t in 1:n.AM){
  points(x=U.mat.AM[,t], y=Y.mat.AM[,t]-shift, pch=21, cex=1, lwd=1,
         bg=matrix(clrs.vec.AM,m)[1,t],  col=matrix(clrs.vec.AM,m)[1,t])
}
temp <- legend("bottomright", legend = rep(" ", 6), text.width = strwidth("aaa"),
               pch = c(19), xjust = 1, yjust = 1, col=rev(base.cols)[seq(1,11,by=2)],
               title = "°C", cex=1.1, box.col = grey(.7), bg= grey(.7))
text(temp$rect$left + temp$rect$w, temp$text$y,
     as.character(rev(seq(round(min(c(Z.vec.AM,Z.vec.AM),na.rm=TRUE),digits=0), 
                      round(max(c(Z.vec.AM,Z.vec.AM),na.rm=TRUE),digits=0), by=7))), pos=2,cex=.9)
box()
dev.off()


## #####################################
## Figure 3: Univariate time series plot
## #####################################
## pdf(paste0(plot_path, "Fig_3.pdf"), width=8, height=3.5)
par(mfrow=c(1,1), mar=c(2.25,4,2.5,1.5)+0.1, font.main=1, family = "serif", ps = 13)
loc1  <- length(Y.reord.BM.vec)
loc2  <- length(c(Y.reord.BM.vec,Y.reord.AM.vec))
plot(c(c(Y.reord.BM.vec), c(Y.reord.AM.vec)),
     lwd=.8,xlab="",ylab="Electr. Prices (EUR/MWh)",axes=F,xlim=c(1,loc2), type="n", 
     ylim=c(20, max(c(c(Y.reord.BM.vec),c(Y.reord.AM.vec)))))
rect(par("usr")[1], par("usr")[3], par("usr")[2], par("usr")[4], col = gray(1), border=gray(1))
##
rect(loc1, par("usr")[3], loc2, par("usr")[4],       col = gray(.85), border=gray(.85))
rect(par("usr")[1], par("usr")[3], 1, par("usr")[4], col = gray(1),   border=gray(1))
rect(loc1-(n_days_TF1*12/2), par("usr")[3], loc1+(n_days_TF1*12/2), 125, 
     col = alpha(gray(.75), .75), border=alpha(gray(.75), .75))
##
lines(c(c(Y.reord.BM.vec), c(Y.reord.AM.vec)), lwd=.8)
text(x=loc1/2,y=175,                labels="One year before\nGermany's nuclear phaseout")
text(x=c(loc1+(loc2-loc1)/2),y=175, labels="First year after\nGermany's nuclear phaseout")
box()
axis(1,at=c(1, loc1-(n_days_TF1*12/2), loc1+(n_days_TF1*12/2), loc2), labels=FALSE)
text(labels = c("+24 days"), x = c(loc1-(n_days_TF1*12/2)), adj = .8,
     y=par()$usr[3]-0.1*(par()$usr[4]-par()$usr[3]), xpd=TRUE)
text(labels = c("-24 days"), x = c(loc1+(n_days_TF1*12/2)), adj = .2,
     y=par()$usr[3]-0.1*(par()$usr[4]-par()$usr[3]), xpd=TRUE)
text(labels = c("Mar. 15, 2010", "Mar. 14, 2012"), x = c(1,loc2),
     y=par()$usr[3]-0.1*(par()$usr[4]-par()$usr[3]), xpd=TRUE)
axis(3, at = loc1, labels = FALSE)
text(labels = c("Mar. 15, 2011"), x = loc1,
     y=par()$usr[4]+0.1*(par()$usr[4]-par()$usr[3]), xpd=TRUE)
axis(2)
par(mfrow=c(1,1), mar=c(5,4,4,2)+0.1)
dev.off()


## #################################
## Choose event study time frame:
## #################################
Y.mat.BM       <- Y.mat.BM[,  (n.BM - n_days_TF1/2 +1):n.BM]
U.mat.BM       <- U.mat.BM[,  (n.BM - n_days_TF1/2 +1):n.BM]
Z.mat.BM       <- Z.mat.BM[,  (n.BM - n_days_TF1/2 +1):n.BM]
Da.vec.BM      <- Da.vec.BM[  (n.BM - n_days_TF1/2 +1):n.BM]
clrs.vec.BM    <- clrs.vec.BM[(n.BM - n_days_TF1/2 +1):n.BM]
##
Y.mat.AM       <- Y.mat.AM[,  1:(n_days_TF1/2)]
U.mat.AM       <- U.mat.AM[,  1:(n_days_TF1/2)]
Z.mat.AM       <- Z.mat.AM[,  1:(n_days_TF1/2)]
Da.vec.AM      <- Da.vec.AM[  1:(n_days_TF1/2)]
clrs.vec.AM    <- clrs.vec.AM[1:(n_days_TF1/2)]
##
Y.vec.BM       <- c(Y.mat.BM)
U.vec.BM       <- c(U.mat.BM)
Z.vec.BM       <- c(Z.mat.BM)
any(is.na(c(Y.vec.BM, U.vec.BM, Z.vec.BM)))
##
Y.vec.AM       <- c(Y.mat.AM)
U.vec.AM       <- c(U.mat.AM)
Z.vec.AM       <- c(Z.mat.AM)
any(is.na(c(Y.vec.AM, U.vec.AM, Z.vec.AM)))
##
Y.mat.reord.BM <- Y.mat.reord.BM[,(n.BM - n_days_TF1/2 +1):n.BM]
U.mat.reord.BM <- U.mat.reord.BM[,(n.BM - n_days_TF1/2 +1):n.BM]
Y.mat.reord.AM <- Y.mat.reord.AM[,1:(n_days_TF1/2)]
U.mat.reord.AM <- U.mat.reord.AM[,1:(n_days_TF1/2)]
##
Y.reord.BM.vec <- c(Y.mat.reord.BM)
U.reord.BM.vec <- c(U.mat.reord.BM)
Y.reord.AM.vec <- c(Y.mat.reord.AM)
U.reord.AM.vec <- c(U.mat.reord.AM)


## #########################################################
## Choosing a set of common evaluation points for testing:
## #########################################################
## Common (before and after atom moratorium) temperture range for BM and AM:
z.lo    <- 5.3 
z.up    <- 8.5 
##
Z.slct.BM <- Z.mat.BM[1,] >= z.lo & Z.mat.BM[1,] <= z.up
Z.slct.AM <- Z.mat.AM[1,] >= z.lo & Z.mat.AM[1,] <= z.up

Z.min.all <- min(Z.vec.BM[rep(Z.slct.BM,each=m)], Z.vec.AM[rep(Z.slct.AM,each=m)])
Z.max.all <- max(Z.vec.BM[rep(Z.slct.BM,each=m)], Z.vec.AM[rep(Z.slct.AM,each=m)])
##
Y.min.all <- min(Y.vec.BM[rep(Z.slct.BM,each=m)], Y.vec.AM[rep(Z.slct.AM,each=m)])
Y.max.all <- max(Y.vec.BM[rep(Z.slct.BM,each=m)], Y.vec.AM[rep(Z.slct.AM,each=m)])
##
z.delta <- 0.5 ## offset to avoid boundary problems
z.TP    <- seq(Z.min.all + z.delta, Z.max.all - z.delta, len=4)


## subselect data from the common tempreture range
Y.mat.BM <- Y.mat.BM[,Z.slct.BM]
U.mat.BM <- U.mat.BM[,Z.slct.BM]
Z.mat.BM <- Z.mat.BM[,Z.slct.BM]
n.BM     <- ncol(Z.mat.BM)
##
Y.mat.AM <- Y.mat.AM[,Z.slct.AM]
U.mat.AM <- U.mat.AM[,Z.slct.AM]
Z.mat.AM <- Z.mat.AM[,Z.slct.AM]
n.AM     <- ncol(Z.mat.AM)
##
Y.vec.BM       <- c(Y.mat.BM)
U.vec.BM       <- c(U.mat.BM)
Z.vec.BM       <- c(Z.mat.BM)
##
Y.vec.AM       <- c(Y.mat.AM)
U.vec.AM       <- c(U.mat.AM)
Z.vec.AM       <- c(Z.mat.AM)

## #################################################################
## Estimation of Boundary Functions a() and b()                   ##
## #################################################################
source("AUX_FILES/Boundary_estimation.R")                         ##
## This is based on:                                              ##
## Martins-Filho, C. and F. Yao (2007).                           ##
## Nonparametric frontier estimation via local linear regression. ##
## Journal of Econometrics 141 (1), 283–319.                      ##
## #################################################################

## ################################################
## Select test-points (TP) within the common support 
## ################################################
U.min.TP    <- optimize(function(x)U.rangeFun(x,BM=TRUE)$lower, lower = Z.min.all, upper = Z.max.all, maximum = FALSE)$objective
U.max.TP    <- optimize(function(x)U.rangeFun(x,AM=TRUE)$upper, lower = Z.min.all, upper = Z.max.all, maximum = TRUE)$objective
##  
u.TP        <- seq(U.min.TP, U.max.TP, len=8)
u.TP.mat    <- matrix(u.TP, nrow=length(u.TP), ncol=length(z.TP))

u.delta      <- 0
for(j in 1:length(z.TP)){
	tmp.slct <- u.TP.mat[,j] < min(U.rangeFun(z.TP[j],BM=TRUE)$upper-u.delta, U.rangeFun(z.TP[j],AM=TRUE)$upper-u.delta) &
	            u.TP.mat[,j] > max(U.rangeFun(z.TP[j],BM=TRUE)$lower+u.delta, U.rangeFun(z.TP[j],AM=TRUE)$lower+u.delta)
	u.TP.mat[,j][!tmp.slct] <- NA
}

## Chosen test points:
(uz.TP.mat <- cbind(c(u.TP.mat), rep(z.TP, each=nrow(u.TP.mat)))[!is.na(c(u.TP.mat)),])
##
u.TP       <- uz.TP.mat[,1]
z.TP       <- uz.TP.mat[,2]
rm(uz.TP.mat)


## #########################################################
## Standardize U and Z to [0,1]^2
## #########################################################
## BM
U.vec.orig.BM <- U.vec.BM
U.vec.BM      <- (U.vec.BM - U.rangeFun(Z.vec.BM, BM=TRUE)$lower)/(U.rangeFun(Z.vec.BM, BM=TRUE)$upper-U.rangeFun(Z.vec.BM, BM=TRUE)$lower)
U.vec.BM[U.vec.BM<0] <- 0
Z.vec.orig.BM <- Z.vec.BM
Z.vec.BM      <- (Z.vec.BM - Z.min.all)/(Z.max.all - Z.min.all)
## AM
U.vec.orig.AM <- U.vec.AM
U.vec.AM      <- (U.vec.AM - U.rangeFun(Z.vec.AM, AM=TRUE)$lower)/(U.rangeFun(Z.vec.AM, AM=TRUE)$upper-U.rangeFun(Z.vec.AM, AM=TRUE)$lower)
Z.vec.orig.AM <- Z.vec.AM
Z.vec.AM      <- (Z.vec.AM - Z.min.all)/(Z.max.all - Z.min.all)

## Scale also the test-points:
u.orig.TP   <- u.TP
u.TP.BM     <- (u.orig.TP - U.rangeFun(z.TP, BM=TRUE)$lower)/(U.rangeFun(z.TP, BM=TRUE)$upper-U.rangeFun(z.TP, BM=TRUE)$lower)
u.TP.AM     <- (u.orig.TP - U.rangeFun(z.TP, AM=TRUE)$lower)/(U.rangeFun(z.TP, AM=TRUE)$upper-U.rangeFun(z.TP, AM=TRUE)$lower)
z.orig.TP   <- z.TP
z.TP.BM     <- (z.orig.TP - Z.min.all)/(Z.max.all - Z.min.all)
z.TP.AM     <- (z.orig.TP - Z.min.all)/(Z.max.all - Z.min.all)

rm(u.TP,z.TP)

## ####################
## Main computations
## ####################

#########
## BM  ##
#########
Y.vec <- Y.vec.BM
U.vec <- U.vec.BM
Z.vec <- Z.vec.BM
n     <- n.BM
M     <- m^2-m
##
Y.mat <- matrix(Y.vec,m,n)
U.mat <- matrix(U.vec,m,n)
Z.mat <- matrix(Z.vec,m,n)
##
u.TP <- u.TP.BM
z.TP <- z.TP.BM
##

## This takes some time ... 
source("AUX_FILES/Main_computations.R")  

## ###############################################################
## Save all necessary results:
## ###############################################################
## Needed for estimating the mean function for plotting:   
YUZ.bigmat.BM   <- YUZ.bigmat  
hu.mean.BM      <- hu.mean.GCV 
hz.mean.BM      <- hz.mean.GCV 
hDDu.u.mean.BM  <- hDDu.u.mean.GCV
hDDu.z.mean.BM  <- hDDu.z.mean.GCV
hDDz.u.mean.BM  <- hDDz.u.mean.GCV
hDDz.z.mean.BM  <- hDDz.z.mean.GCV

## For hypothesis testing
## Bias-corrected estimation of the mean-function @ test-points:                    
mean.hat.BC.TP.BM <- mean.hat.BC.TP
## Estimated standard deviations @ test-points:
sd.hat.TP.BM      <- sd.hat.TP    
## ###############################################################

#########
## AM  ##
#########
Y.vec <- Y.vec.AM
U.vec <- U.vec.AM
Z.vec <- Z.vec.AM
n     <- n.AM
M     <- m^2-m
##
Y.mat <- matrix(Y.vec,m,n)
U.mat <- matrix(U.vec,m,n)
Z.mat <- matrix(Z.vec,m,n)
##
u.TP <- u.TP.AM
z.TP <- z.TP.AM
##

## This takes some time ... 
source("AUX_FILES/Main_computations.R")  

## ###############################################################
## Save all necessary results:
## ###############################################################
## Needed for estimating the mean function for plotting   
YUZ.bigmat.AM   <- YUZ.bigmat     
hu.mean.AM      <- hu.mean.GCV
hz.mean.AM      <- hz.mean.GCV
hDDu.u.mean.AM  <- hDDu.u.mean.GCV
hDDu.z.mean.AM  <- hDDu.z.mean.GCV
hDDz.u.mean.AM  <- hDDz.u.mean.GCV
hDDz.z.mean.AM  <- hDDz.z.mean.GCV

## For hypothesis testing
## Bias-corrected estimations of the mean-function @ test-points:               
mean.hat.BC.TP.AM <- mean.hat.BC.TP
## Estimated standard deviations @ test-points:
sd.hat.TP.AM      <- sd.hat.TP    
## ###############################################################

## ###############################################################
## Testing for differences in the mean functions @ test-points 
## ###############################################################

## We expect that the mean is LARGER after the moratorium (AM)
## H_0: mu.AM = mu.BM
## H_1: mu.AM > mu.BM

## One-sided significance level with Bonferroni correction
alpha.Bonf   <- 0.05/length(u.TP)

## One-sided hypothesis-test:
T.vec    <- c(mean.hat.BC.TP.AM - mean.hat.BC.TP.BM)/sqrt(sd.hat.TP.AM^2 + sd.hat.TP.BM^2)

p.values <- pnorm(q=T.vec, lower.tail = FALSE)

## Significant result?
signif.results <- p.values < alpha.Bonf
## Overview
cbind(c(mean.hat.BC.TP.AM - mean.hat.BC.TP.BM), p.values, signif.results)


## ################################
## Compute data for plotting
## ################################
## 1. Differences in mean functions
u.eval   <- seq(U.min.TP,  U.max.TP,  len=200)
z.eval   <- seq(Z.min.all, Z.max.all, len=200)
## 
mean.hat.BM.plotting <- matrix(NA, nrow=length(u.eval), ncol=length(z.eval))
mean.hat.AM.plotting <- matrix(NA, nrow=length(u.eval), ncol=length(z.eval))
##
for(j in 1:length(z.eval)){
  u.slct <- u.eval >= max(U.rangeFun(z.eval[j], BM=TRUE)$lower, U.rangeFun(z.eval[j], AM=TRUE)$lower) & 
    u.eval <= min(U.rangeFun(z.eval[j], BM=TRUE)$upper, U.rangeFun(z.eval[j], AM=TRUE)$upper) 
  for(k in c(1:length(u.eval))[u.slct]){
    ##
    u.eval.BM.tmp <- c((u.eval[k] - U.rangeFun(z.eval[j], BM=TRUE)$lower)/(U.rangeFun(z.eval[j], BM=TRUE)$upper-U.rangeFun(z.eval[j], BM=TRUE)$lower))
    z.eval.BM.tmp <- c((z.eval[j] - Z.min.all)/(Z.max.all - Z.min.all)) 
    ##
    mean.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.BM,
                             hu         = hu.mean.BM,
                             hz         = hz.mean.BM,
                             u.eval     = u.eval.BM.tmp,
                             z.eval     = z.eval.BM.tmp,
                             kernel     = kernel)[['y.hat']]
    ## Bias
    mean.DDu.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.BM,
                                 hu         = hDDu.u.mean.BM,
                                 hz         = hDDu.z.mean.BM,
                                 u.eval     = u.eval.BM.tmp,
                                 z.eval     = z.eval.BM.tmp,
                                 kernel     = kernel,
                                 DD.est     = TRUE)[['y.hat.DDu']]
    mean.DDz.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.BM,
                                 hu         = hDDz.u.mean.BM,
                                 hz         = hDDz.z.mean.BM,
                                 u.eval     = u.eval.BM.tmp,
                                 z.eval     = z.eval.BM.tmp,
                                 kernel     = kernel,
                                 DD.est     = TRUE)[['y.hat.DDz']]
    mean.hat.BM.plotting[k,j] <- mean.tmp - (1/2) * (nu2_kappa^2) * (hu.mean.BM^2 * mean.DDu.tmp + hz.mean.BM^2 * mean.DDz.tmp) 
    ##
    u.eval.AM.tmp <- c((u.eval[k] - U.rangeFun(z.eval[j], AM=TRUE)$lower)/(U.rangeFun(z.eval[j], AM=TRUE)$upper-U.rangeFun(z.eval[j], AM=TRUE)$lower))
    z.eval.AM.tmp <- c((z.eval[j] - Z.min.all)/(Z.max.all - Z.min.all)) 
    ##
    mean.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.AM,
                                              hu         = hu.mean.AM,
                                              hz         = hz.mean.AM,
                                              u.eval     = u.eval.AM.tmp,
                                              z.eval     = z.eval.AM.tmp,
                                              kernel     = kernel)[['y.hat']]
    ## Bias
    mean.DDu.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.AM,
                                 hu         = hDDu.u.mean.AM,
                                 hz         = hDDu.z.mean.AM,
                                 u.eval     = u.eval.AM.tmp,
                                 z.eval     = z.eval.AM.tmp,
                                 kernel     = kernel,
                                 DD.est     = TRUE)[['y.hat.DDu']]
    mean.DDz.tmp <- KLL_mean_fun(YUZ.bigmat = YUZ.bigmat.AM,
                                 hu         = hDDz.u.mean.AM,
                                 hz         = hDDz.z.mean.AM,
                                 u.eval     = u.eval.AM.tmp,
                                 z.eval     = z.eval.AM.tmp,
                                 kernel     = kernel,
                                 DD.est     = TRUE)[['y.hat.DDz']]
    mean.hat.AM.plotting[k,j] <- mean.tmp - (1/2) * (nu2_kappa^2) * (hu.mean.AM^2 * mean.DDu.tmp + hz.mean.AM^2 * mean.DDz.tmp) 
    
  }
  cat("j/",length(z.eval),"=",j,"/",length(z.eval),"\n")
}
##
mean.hat.diff.plotting <- mean.hat.AM.plotting - mean.hat.BM.plotting

## ###########################################################
## 2. Quadratic interaction function plus confidence interval
## ###########################################################
demand_seq     <- seq(U.min.TP, U.max.TP, len=25)
effect_seq_BM  <- coef(fit_BM_2_4)[2] + coef(fit_BM_2_4)[5] * demand_seq + coef(fit_BM_2_4)[6] * demand_seq^2
##
X_ES   <- cbind(dummy_AM_ES, I(res_demand_PHmean_ES * dummy_AM_ES), I(res_demand_PHmean_ES^2 * dummy_AM_ES))
XtX_ES <- t(X_ES) %*% X_ES
X_0    <- as.matrix(data.frame(1, demand_seq, demand_seq^2))
##
CI_BM      <- qt(0.975, nrow(X_ES)) * summary(fit_BM_2_4)$sigma * sqrt(1+diag(X_0 %*% chol2inv(XtX_ES) %*% t(X_0)))
CI_plot_BM <- cbind(effect_seq_BM - CI_BM, effect_seq_BM, effect_seq_BM + CI_BM)



## ###################################################
## Figure 4: Test and Estimation results 
## ###################################################
## pdf(paste0(plot_path,"Fig_4.pdf"), width=8.5, height=3.5) 
par(mfrow=c(1,2), mar=c(3.8,5,1,0)+0.1, font.main=1, family="serif", ps=13)
cex.value <- 0.95
image(y=z.eval, x=u.eval, z=mean.hat.diff.plotting, main="", col = gray(seq(.975,0.3,len=14), alpha=0.75), 
      ylab="Temperature (°C)", xlab="Residual Demand (MW)", useRaster = TRUE)
##
points(x=u.orig.TP, y=z.orig.TP, bg="black", pch=c(rep(21,4), rep(25,6), rep(24,4), rep(22,4)))
text(x=u.orig.TP[signif.results], y=z.orig.TP[signif.results], pos=1,
     labels=c(paste0("+",round(c(mean.hat.BC.TP.AM - mean.hat.BC.TP.BM)[signif.results], digits=0))), cex=cex.value)
if(any(!signif.results)){
  text(  x=u.orig.TP[!signif.results], y=z.orig.TP[!signif.results], pos=1, labels="(N)", cex=cex.value)
  points(x=u.orig.TP[!signif.results], y=z.orig.TP[!signif.results], bg="gray", pch=c(rep(21,1), rep(25,2), rep(24,0), rep(22,2)))
}
for(zz in unique(z.orig.TP)){
  zz.loc     <- which.min(abs(zz - z.eval))
  lines(x = u.eval[!is.na(mean.hat.diff.plotting[,zz.loc])], 
        y = rep(zz, length(u.eval[!is.na(mean.hat.diff.plotting[,zz.loc])])), lty=3)
}
####
matplot(x    = demand_seq, y = CI_plot_BM, type="n", 
        xlab = "Residual Demand (MW)", ylab = "EUR/MWh",
        ylim = range(-7, 28, na.rm=T), lty=c(2,1,2), col=gray(.5))
##
polygon(x = c(demand_seq,      rev(demand_seq)),
        y = c(CI_plot_BM[,1], rev(CI_plot_BM[,3])), border = alpha(gray(.75), .5), col = alpha(gray(.75), .5))
lines(x = demand_seq, y = CI_plot_BM[,2])
##
lines(y = spline(x = Grossi_Fig6_df$X, y = Grossi_Fig6_df$Y, xout = demand_seq)$y,
      x = demand_seq, lty=2)
## 
legend("topleft", legend = c("Benchmark", "with 95% CI", "Grossi et al. (2017)", "Nonparametric"), 
       lty=c(1,NA,2,3),  lwd=c(15,NA,1,1), col=c(gray(.75), "black", "black", "black"), bty = "n", cex = 1, y.intersp=1)
legend("topleft", legend = c("Benchmark", "with 95% CI", "Grossi et al. (2017)", "Nonparametric"), 
       lty=c(1,NA,NA,NA), text.col = alpha("white", alpha = 0), col=c("black"), bty="n", cex = 1, y.intersp=1)
###
uu_plot <- numeric(length(u.orig.TP))
dd_plot <- numeric(length(u.orig.TP))
count   <- 1
for(zz in unique(z.orig.TP)){
  zz.loc     <- which.min(abs(zz - z.eval))
  uu.vec     <- u.orig.TP[which(zz == z.orig.TP)]
  matlines(x = u.eval, y = mean.hat.diff.plotting[,zz.loc], lty=3, col="black")
  for(uu in uu.vec){
    uu.loc     <- which.min(abs(uu - u.eval))
    uu_plot[count] <- u.eval[uu.loc]
    dd_plot[count] <- mean.hat.diff.plotting[uu.loc, zz.loc]
    points(x = uu_plot[count], y = dd_plot[count], 
           pch=c(21,25,24,22)[match(zz,unique(z.orig.TP))], 
           bg="black")
    count <- count + 1
  }
}
if(any(!signif.results)){
  points(x=uu_plot[!signif.results], y = dd_plot[!signif.results], bg="gray", pch=c(rep(21,1), rep(25,2), rep(24,0), rep(22,2)))
}
dev.off()


## The End ##