Supplement B for "Modeling and Forecasting Electricity Spot Prices" 
Author:  Dominik Liebl (dliebl@uni-bonn.de)

------------------------------------------
Content: 
One directory:
AUX_FUN_and_DATA (Contains auxiliary R files and the dataset)

Three R files:
1_TwoStepEstim.R
2_VARIMAX.R
3_TS_Analysis_and_Forecasting.R
------------------------------------------

Sequence for the usage of the R-files:
1_TwoStepEstim.R 
produces: TwoStepEstim.RData

2_VARIMAX.R 
loads: TwoStepEstim.RData
produces: VARIMAX.RData

3_TS_Analysis_and_Forecasting.R
loads: VARIMAX.RData
